# Roadmap — EAU Attendance improvements (from uploaded brief)

- [x] Remove the embedded Attendance AI section and its Help toggle at the user's request; preserve attendance records and the standalone assistant.

- [x] Add class filtering alongside semester in monthly reports; totals, charts and downloads share the selected class; eight monthly-report tests passed. Signed-in verification remains blocked by the existing missing requester account.

- [x] Add a month selector to Reports & Analysis, monthly per-student present/absent totals including students with no records, and month-labelled Excel/PDF exports; eight utility tests passed and October database totals read back (24 present, 3 absent).
- [ ] Verify monthly report and downloads in a signed-in browser; blocked because the requester has no matching app account; public check redirects to sign-in without page errors.

- [x] Correct BCS Semester 7 and 8 from the uploaded Semester Seven sheet: 44 names each, original IDs and all 28 attendance/history records preserved; removed 100 unused sample students; two roster tests passed.
- [x] Remove Generate 50 samples from Students; refine Courses vertical semester lists with department above search, and Teachers with strong separators; build OK.
- [x] Reduce login image transfer from 232 KB to 102 KB, remove backdrop blur and global logo preload, and add user-keyed cached catalogue loaders; public login and mobile checked without runtime errors, 11 tests passed. Local LCP was 340 ms before and 408 ms after; no production speed improvement claimed.
- [ ] Verify Students, Courses and Teachers in a signed-in browser; requester has no matching app account, so sign-in in preview is required.

- [x] Restore complete vertical course rows under each semester with teacher, hours and edit/delete; saved 68 courses at 4 hours and retained 3 Semester 3 English courses at 6; five rule tests passed and build OK.
- [ ] Verify updated Courses in a signed-in browser; blocked because preview is signed out, requester has no matching app account and multiple accounts prevent automatic session selection.

- [x] Show live assigned courses instead of Specialty in Teachers; redesign Courses with department filters, semester groups and individual cards; verified signed-in course search, four credit hours and Edit dialog, mobile width and four existing rule tests; no stored data changed.

- [x] Imported 27 PDF teachers and assigned all 71 existing courses in courses and lecturer_courses; stored BBA Computerized Accounting 4 hours and Semester 3 English 6 hours, kept SHR Semester 5 English; verified signed-in Teachers, course edit and BBA attendance sheet; all 608 students preserved, attendance/history unchanged, four rule tests passed.

- [x] Removed 17 BCS courses outside semesters 3, 5 and 7 and their 903 enrollment links; all 608 students preserved, no attendance/history existed on removed courses; verified zero remaining outside 3/5/7 and browser course selectors.

- [x] Imported the ten SHR Arabic student names into each of semesters 5–8; eight timetable courses only in Semester 5 with 80 enrollments; verified all four Students rosters and Semester 5 Attendance Sheet.

- [x] Import BNUR Semester 3, 5 and 7 timetable courses (5/6/6) and BCO Semester 7 roster (16 students) and six courses; verified 430 enrollments and signed-in Students/Attendance Sheet without changing previous records.

- [x] Import uploaded BBA Semester 7 roster: 19 nonempty names from Semester Seven sheet, six timetable courses and 114 enrollments; preserve existing records.
- [x] Separate attendance weeks with colored borders and label every class day, including Wednesday and final partial weeks; calendar tests passed.
- [x] Verify Semester 7 in Students and Attendance Sheet as signed-in admin: 19 students, six courses, five October weeks and blue week separators; no browser errors.

- [x] Correct BBA faculty name to Business and Administration; Semester 5's six existing courses match the supplied timetable, with no duplicates added; verified name and course in Attendance Sheet.

- [x] 1. Reports page (/reports): daily/weekly/monthly/semester tabs, per-student %, dept/sem/course/date filters, recharts trend chart, course ranking, Excel (xlsx) + print-PDF export
- [x] 2. AI Assistant (/assistant): createServerFn + requireSupabaseAuth, admin/teacher role gate, deterministic RPC data retrieval grounded in real rows, gpt-6-astra phrasing via gateway
- [x] 3. Analysis: high-absence flagging with configurable threshold (Settings), trend charts, course ranking
- [x] 4. Permanent storage: attendance + attendance_log triggers + recorded_at already in DB (verified)
- [x] 5. Student history page: date-range + course filter added and verified in browser
- [x] 6. DB accuracy: indexes exist, unique constraints, new report RPCs added (attendance_student_stats, attendance_daily_stats, attendance_course_stats, attendance_student_lookup)
- [x] 7. Roles: admin + teacher only in user_roles; viewer has no AI access
- [x] 8. Nav: added Reports & Analysis, AI Assistant, Settings
- [x] 9. Verified in browser (admin session): Reports renders 866 students + charts + flags; AI Assistant answered a real question from DB data; student history filters present; marks panel shows real marks (fixed function to count attendance rows, not only sessions)
