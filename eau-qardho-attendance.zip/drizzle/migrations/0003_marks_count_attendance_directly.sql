-- Count attendance rows directly instead of only completed sessions,
-- so historical records (saved before class_sessions existed) still count.
create or replace function public.course_attendance_marks(p_course uuid)
returns table(
  student_id uuid, student_name text, student_no text,
  completed bigint, present bigint, absent bigint, late bigint,
  pct numeric, marks numeric, max_marks smallint
)
language sql stable security definer set search_path = public
as $$
  select s.id, s.full_name, s.student_no,
    count(a.id) as completed,
    count(*) filter (where a.status = 'present') as present,
    count(*) filter (where a.status = 'absent') as absent,
    count(*) filter (where a.status = 'late') as late,
    round(count(*) filter (where a.status in ('present','late')) * 100.0 / nullif(count(a.id), 0), 1) as pct,
    round(c.attendance_max_marks * coalesce(count(*) filter (where a.status in ('present','late')), 0)::numeric / nullif(count(a.id), 0), 1) as marks,
    c.attendance_max_marks
  from public.students s
  join public.courses c on c.id = p_course and c.department_id = s.department_id and c.semester = s.semester
  left join public.attendance a on a.student_id = s.id and a.course_id = p_course
  group by s.id, s.full_name, s.student_no, c.attendance_max_marks
  order by s.full_name
$$;

create or replace function public.attendance_monthly_report(p_course uuid, p_month date)
returns table(
  student_id uuid, student_name text, student_no text,
  completed bigint, present bigint, absent bigint, late bigint,
  pct numeric, marks numeric
)
language sql stable security definer set search_path = public
as $$
  select s.id, s.full_name, s.student_no,
    count(a.id) as completed,
    count(*) filter (where a.status = 'present') as present,
    count(*) filter (where a.status = 'absent') as absent,
    count(*) filter (where a.status = 'late') as late,
    round(count(*) filter (where a.status in ('present','late')) * 100.0 / nullif(count(a.id), 0), 1) as pct,
    round(c.attendance_max_marks * coalesce(count(*) filter (where a.status in ('present','late')), 0)::numeric / nullif(count(a.id), 0), 1) as marks
  from public.students s
  join public.courses c on c.id = p_course and c.department_id = s.department_id and c.semester = s.semester
  left join public.attendance a on a.student_id = s.id and a.course_id = p_course
    and a.date >= date_trunc('month', p_month)::date
    and a.date < (date_trunc('month', p_month) + interval '1 month')::date
  group by s.id, s.full_name, s.student_no, c.attendance_max_marks
  order by s.full_name
$$;