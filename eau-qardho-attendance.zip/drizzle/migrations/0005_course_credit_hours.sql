ALTER TABLE public.courses ADD COLUMN IF NOT EXISTS credit_hours numeric(4,1);
ALTER TABLE public.courses ADD CONSTRAINT courses_credit_hours_positive CHECK (credit_hours IS NULL OR credit_hours > 0);
COMMENT ON COLUMN public.courses.credit_hours IS 'Confirmed course credit hours; null means not supplied. Independent of attendance duration.';