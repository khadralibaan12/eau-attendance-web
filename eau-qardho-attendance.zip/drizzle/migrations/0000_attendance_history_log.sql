ALTER TABLE public.attendance ADD COLUMN IF NOT EXISTS semester smallint;
ALTER TABLE public.attendance ADD COLUMN IF NOT EXISTS department_id uuid;
ALTER TABLE public.attendance ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

UPDATE public.attendance a SET semester = c.semester, department_id = c.department_id
FROM public.courses c WHERE c.id = a.course_id AND a.semester IS NULL;

CREATE INDEX IF NOT EXISTS attendance_student_idx ON public.attendance(student_id, date DESC);
CREATE INDEX IF NOT EXISTS attendance_dept_sem_idx ON public.attendance(department_id, semester, date DESC);

CREATE TABLE IF NOT EXISTS public.attendance_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  attendance_id uuid,
  student_id uuid NOT NULL,
  course_id uuid NOT NULL,
  department_id uuid,
  semester smallint,
  date date NOT NULL,
  old_status attendance_status,
  new_status attendance_status,
  action text NOT NULL,
  changed_by uuid,
  changed_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.attendance_log TO authenticated;
GRANT ALL ON public.attendance_log TO service_role;
ALTER TABLE public.attendance_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "view attendance log" ON public.attendance_log FOR SELECT TO authenticated USING (true);
CREATE INDEX IF NOT EXISTS attendance_log_student_idx ON public.attendance_log(student_id, changed_at DESC);

CREATE OR REPLACE FUNCTION public.attendance_fill_meta()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  SELECT c.semester, c.department_id INTO NEW.semester, NEW.department_id FROM public.courses c WHERE c.id = NEW.course_id;
  NEW.updated_at := now();
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS attendance_fill_meta_trg ON public.attendance;
CREATE TRIGGER attendance_fill_meta_trg BEFORE INSERT OR UPDATE ON public.attendance
FOR EACH ROW EXECUTE FUNCTION public.attendance_fill_meta();

CREATE OR REPLACE FUNCTION public.attendance_write_log()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.attendance_log(attendance_id, student_id, course_id, department_id, semester, date, old_status, new_status, action, changed_by)
    VALUES (NEW.id, NEW.student_id, NEW.course_id, NEW.department_id, NEW.semester, NEW.date, NULL, NEW.status, 'created', auth.uid());
  ELSIF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    INSERT INTO public.attendance_log(attendance_id, student_id, course_id, department_id, semester, date, old_status, new_status, action, changed_by)
    VALUES (NEW.id, NEW.student_id, NEW.course_id, NEW.department_id, NEW.semester, NEW.date, OLD.status, NEW.status, 'changed', auth.uid());
  ELSIF TG_OP = 'DELETE' THEN
    INSERT INTO public.attendance_log(attendance_id, student_id, course_id, department_id, semester, date, old_status, new_status, action, changed_by)
    VALUES (OLD.id, OLD.student_id, OLD.course_id, OLD.department_id, OLD.semester, OLD.date, OLD.status, NULL, 'deleted', auth.uid());
    RETURN OLD;
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS attendance_write_log_trg ON public.attendance;
CREATE TRIGGER attendance_write_log_trg AFTER INSERT OR UPDATE OR DELETE ON public.attendance
FOR EACH ROW EXECUTE FUNCTION public.attendance_write_log();

INSERT INTO public.attendance_log(attendance_id, student_id, course_id, department_id, semester, date, new_status, action, changed_at)
SELECT id, student_id, course_id, department_id, semester, date, status, 'created', created_at FROM public.attendance;