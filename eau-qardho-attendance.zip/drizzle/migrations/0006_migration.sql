do $$
declare t text; p text;
begin
  for t, p in select * from (values ('attendance','view attendance'),('students','view students'),('lecturer_courses','view lecturer courses'),('class_sessions','view class sessions'),('attendance_log','view attendance log'),('enrollments','view enrollments'),('courses','view courses')) v(t,p) loop
    execute format('drop policy if exists %I on public.%I', p, t);
    execute format('create policy %I on public.%I for select to authenticated using (public.has_role(auth.uid(), ''admin''::app_role) or public.has_role(auth.uid(), ''teacher''::app_role))', p, t);
  end loop;
end $$;