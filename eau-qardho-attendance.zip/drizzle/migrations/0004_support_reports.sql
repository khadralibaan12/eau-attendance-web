CREATE TABLE public.support_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  name text NOT NULL,
  contact text,
  category text NOT NULL DEFAULT 'Bug',
  message text NOT NULL,
  status text NOT NULL DEFAULT 'Open',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.support_reports TO authenticated;
GRANT ALL ON public.support_reports TO service_role;
ALTER TABLE public.support_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "insert own report" ON public.support_reports FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "view own or admin" ON public.support_reports FOR SELECT TO authenticated USING (auth.uid() = user_id OR public.has_role(auth.uid(),'admin'));