-- Per-student attendance stats with optional filters (used by Reports, Analysis, AI assistant)
create or replace function public.attendance_student_stats(
  p_dept uuid default null,
  p_sem smallint default null,
  p_course uuid default null,
  p_from date default null,
  p_to date default null
)
returns table(
  student_id uuid, student_name text, student_no text,
  department_id uuid, department_name text, semester smallint,
  present bigint, absent bigint, total bigint, pct numeric
)
language sql stable security definer set search_path = public
as $$
  select s.id, s.full_name, s.student_no, s.department_id, d.name, s.semester,
    count(*) filter (where a.status = 'present') as present,
    count(*) filter (where a.status = 'absent') as absent,
    count(*) as total,
    round(count(*) filter (where a.status = 'present') * 100.0 / nullif(count(*), 0), 1) as pct
  from public.attendance a
  join public.students s on s.id = a.student_id
  join public.departments d on d.id = s.department_id
  where (p_dept is null or s.department_id = p_dept)
    and (p_sem is null or s.semester = p_sem)
    and (p_course is null or a.course_id = p_course)
    and (p_from is null or a.date >= p_from)
    and (p_to is null or a.date <= p_to)
  group by s.id, s.full_name, s.student_no, s.department_id, d.name, s.semester
  order by s.full_name
$$;

-- Daily present/absent counts (trend charts)
create or replace function public.attendance_daily_stats(
  p_dept uuid default null,
  p_sem smallint default null,
  p_course uuid default null,
  p_from date default null,
  p_to date default null
)
returns table(day date, present bigint, absent bigint, pct numeric)
language sql stable security definer set search_path = public
as $$
  select a.date as day,
    count(*) filter (where a.status = 'present') as present,
    count(*) filter (where a.status = 'absent') as absent,
    round(count(*) filter (where a.status = 'present') * 100.0 / nullif(count(*), 0), 1) as pct
  from public.attendance a
  join public.students s on s.id = a.student_id
  where (p_dept is null or s.department_id = p_dept)
    and (p_sem is null or s.semester = p_sem)
    and (p_course is null or a.course_id = p_course)
    and (p_from is null or a.date >= p_from)
    and (p_to is null or a.date <= p_to)
  group by a.date
  order by a.date
$$;

-- Per-course attendance stats
create or replace function public.attendance_course_stats(
  p_dept uuid default null,
  p_sem smallint default null,
  p_from date default null,
  p_to date default null
)
returns table(course_id uuid, course_name text, teacher_name text, present bigint, absent bigint, total bigint, pct numeric)
language sql stable security definer set search_path = public
as $$
  select c.id, c.name, t.full_name,
    count(*) filter (where a.status = 'present') as present,
    count(*) filter (where a.status = 'absent') as absent,
    count(*) as total,
    round(count(*) filter (where a.status = 'present') * 100.0 / nullif(count(*), 0), 1) as pct
  from public.attendance a
  join public.courses c on c.id = a.course_id
  left join public.teachers t on t.id = c.teacher_id
  where (p_dept is null or c.department_id = p_dept)
    and (p_sem is null or c.semester = p_sem)
    and (p_from is null or a.date >= p_from)
    and (p_to is null or a.date <= p_to)
  group by c.id, c.name, t.full_name
  order by c.name
$$;

-- AI assistant: bounded natural-language lookups over real data only
create or replace function public.attendance_student_lookup(p_query text)
returns table(student_id uuid, student_name text, student_no text, department_name text, semester smallint)
language sql stable security definer set search_path = public
as $$
  select s.id, s.full_name, s.student_no, d.name, s.semester
  from public.students s
  join public.departments d on d.id = s.department_id
  where s.full_name ilike '%' || p_query || '%' or s.student_no ilike '%' || p_query || '%'
  order by s.full_name
  limit 20
$$;

-- Index to speed up date-range report queries
CREATE INDEX IF NOT EXISTS attendance_course_date_idx ON public.attendance (course_id, date);