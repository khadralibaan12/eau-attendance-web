
-- 1. Semesters
CREATE TABLE public.semesters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  academic_year text,
  start_date date,
  end_date date,
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.semesters TO authenticated;
GRANT ALL ON public.semesters TO service_role;
ALTER TABLE public.semesters ENABLE ROW LEVEL SECURITY;
CREATE POLICY "view semesters" ON public.semesters FOR SELECT TO authenticated USING (true);
CREATE POLICY "admin manage semesters" ON public.semesters FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- 2. Class sessions
CREATE TABLE public.class_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
  semester_id uuid REFERENCES public.semesters(id) ON DELETE SET NULL,
  lecturer_id uuid REFERENCES public.teachers(id) ON DELETE SET NULL,
  class_date date NOT NULL,
  start_time time,
  end_time time,
  status text NOT NULL DEFAULT 'Scheduled',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (course_id, class_date)
);
CREATE INDEX class_sessions_course_date_idx ON public.class_sessions (course_id, class_date);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.class_sessions TO authenticated;
GRANT ALL ON public.class_sessions TO service_role;
ALTER TABLE public.class_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "view class sessions" ON public.class_sessions FOR SELECT TO authenticated USING (true);
CREATE POLICY "admin manage class sessions" ON public.class_sessions FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "lecturer manage own sessions" ON public.class_sessions FOR ALL TO authenticated
  USING (lecturer_id IN (SELECT id FROM public.teachers WHERE user_id = auth.uid()))
  WITH CHECK (lecturer_id IN (SELECT id FROM public.teachers WHERE user_id = auth.uid()));

-- 3. Enrollments
CREATE TABLE public.enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  course_id uuid NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
  semester_id uuid REFERENCES public.semesters(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'enrolled',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (student_id, course_id)
);
CREATE INDEX enrollments_course_idx ON public.enrollments (course_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.enrollments TO authenticated;
GRANT ALL ON public.enrollments TO service_role;
ALTER TABLE public.enrollments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "view enrollments" ON public.enrollments FOR SELECT TO authenticated USING (true);
CREATE POLICY "admin manage enrollments" ON public.enrollments FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- 4. Lecturer course assignments
CREATE TABLE public.lecturer_courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lecturer_id uuid NOT NULL REFERENCES public.teachers(id) ON DELETE CASCADE,
  course_id uuid NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
  semester_id uuid REFERENCES public.semesters(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (lecturer_id, course_id, semester_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.lecturer_courses TO authenticated;
GRANT ALL ON public.lecturer_courses TO service_role;
ALTER TABLE public.lecturer_courses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "view lecturer courses" ON public.lecturer_courses FOR SELECT TO authenticated USING (true);
CREATE POLICY "admin manage lecturer courses" ON public.lecturer_courses FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- 5. Courses: configurable attendance max marks (default 10)
ALTER TABLE public.courses ADD COLUMN attendance_max_marks smallint NOT NULL DEFAULT 10;

-- 6. Attendance: link to class session + recording timestamp
ALTER TABLE public.attendance ADD COLUMN session_id uuid REFERENCES public.class_sessions(id) ON DELETE SET NULL;
ALTER TABLE public.attendance ADD COLUMN recorded_at timestamptz NOT NULL DEFAULT now();
CREATE UNIQUE INDEX attendance_student_session_uniq ON public.attendance (student_id, session_id) WHERE session_id IS NOT NULL;
CREATE INDEX attendance_session_idx ON public.attendance (session_id);

-- 7. Lecturers may write attendance only for their assigned courses
CREATE POLICY "lecturer write own attendance" ON public.attendance FOR INSERT TO authenticated
  WITH CHECK (course_id IN (
    SELECT lc.course_id FROM public.lecturer_courses lc
    JOIN public.teachers t ON t.id = lc.lecturer_id
    WHERE t.user_id = auth.uid()));
CREATE POLICY "lecturer update own attendance" ON public.attendance FOR UPDATE TO authenticated
  USING (course_id IN (
    SELECT lc.course_id FROM public.lecturer_courses lc
    JOIN public.teachers t ON t.id = lc.lecturer_id
    WHERE t.user_id = auth.uid()));

-- 8. Backfill lecturer assignments from existing course teacher_id
INSERT INTO public.lecturer_courses (lecturer_id, course_id)
SELECT teacher_id, id FROM public.courses WHERE teacher_id IS NOT NULL
ON CONFLICT DO NOTHING;

-- 9. Backfill enrollments: every student enrolled in their department+semester courses
INSERT INTO public.enrollments (student_id, course_id)
SELECT s.id, c.id FROM public.students s
JOIN public.courses c ON c.department_id = s.department_id AND c.semester = s.semester
ON CONFLICT DO NOTHING;

-- 10. Marks calculation: per student for a course (completed sessions only)
CREATE OR REPLACE FUNCTION public.course_attendance_marks(p_course uuid)
RETURNS TABLE(
  student_id uuid,
  student_name text,
  student_no text,
  completed bigint,
  present bigint,
  absent bigint,
  late bigint,
  pct numeric,
  marks numeric,
  max_marks smallint
)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
  SELECT s.id, s.full_name, s.student_no,
    count(a.id) FILTER (WHERE a.status IN ('present','absent','late')) AS completed,
    count(a.id) FILTER (WHERE a.status = 'present') AS present,
    count(a.id) FILTER (WHERE a.status = 'absent') AS absent,
    count(a.id) FILTER (WHERE a.status = 'late') AS late,
    CASE WHEN count(a.id) FILTER (WHERE a.status IN ('present','absent','late')) = 0 THEN 0
         ELSE round(100.0 * count(a.id) FILTER (WHERE a.status = 'present')
              / count(a.id) FILTER (WHERE a.status IN ('present','absent','late')), 2) END AS pct,
    CASE WHEN count(a.id) FILTER (WHERE a.status IN ('present','absent','late')) = 0 THEN 0
         ELSE round(c.attendance_max_marks::numeric * count(a.id) FILTER (WHERE a.status = 'present')
              / count(a.id) FILTER (WHERE a.status IN ('present','absent','late')), 2) END AS marks,
    c.attendance_max_marks
  FROM public.students s
  JOIN public.enrollments e ON e.student_id = s.id AND e.course_id = p_course
  JOIN public.courses c ON c.id = p_course
  LEFT JOIN public.attendance a ON a.student_id = s.id AND a.course_id = p_course
    AND (a.session_id IS NULL OR a.session_id IN (
      SELECT id FROM public.class_sessions WHERE status = 'Completed'))
  GROUP BY s.id, s.full_name, s.student_no, c.attendance_max_marks
  ORDER BY s.full_name
$$;

-- 11. Monthly report: per student, course, month
CREATE OR REPLACE FUNCTION public.attendance_monthly_report(p_course uuid, p_month date)
RETURNS TABLE(
  student_id uuid,
  student_name text,
  student_no text,
  completed bigint,
  present bigint,
  absent bigint,
  late bigint,
  pct numeric,
  marks numeric
)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
  SELECT s.id, s.full_name, s.student_no,
    count(a.id) FILTER (WHERE a.status IN ('present','absent','late')) AS completed,
    count(a.id) FILTER (WHERE a.status = 'present') AS present,
    count(a.id) FILTER (WHERE a.status = 'absent') AS absent,
    count(a.id) FILTER (WHERE a.status = 'late') AS late,
    CASE WHEN count(a.id) FILTER (WHERE a.status IN ('present','absent','late')) = 0 THEN 0
         ELSE round(100.0 * count(a.id) FILTER (WHERE a.status = 'present')
              / count(a.id) FILTER (WHERE a.status IN ('present','absent','late')), 2) END AS pct,
    CASE WHEN count(a.id) FILTER (WHERE a.status IN ('present','absent','late')) = 0 THEN 0
         ELSE round(c.attendance_max_marks::numeric * count(a.id) FILTER (WHERE a.status = 'present')
              / count(a.id) FILTER (WHERE a.status IN ('present','absent','late')), 2) END AS marks
  FROM public.students s
  JOIN public.enrollments e ON e.student_id = s.id AND e.course_id = p_course
  JOIN public.courses c ON c.id = p_course
  LEFT JOIN public.attendance a ON a.student_id = s.id AND a.course_id = p_course
    AND date_trunc('month', a.date) = date_trunc('month', p_month)
    AND (a.session_id IS NULL OR a.session_id IN (
      SELECT id FROM public.class_sessions WHERE status = 'Completed'))
  GROUP BY s.id, s.full_name, s.student_no, c.attendance_max_marks
  ORDER BY s.full_name
$$;
