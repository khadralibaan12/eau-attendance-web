REVOKE ALL ON FUNCTION public.attendance_class_history(uuid, smallint) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.student_attendance_summary(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.attendance_class_history(uuid, smallint) TO authenticated;
GRANT EXECUTE ON FUNCTION public.student_attendance_summary(uuid) TO authenticated;