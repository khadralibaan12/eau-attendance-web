
-- Roles
CREATE TYPE public.app_role AS ENUM ('admin','teacher','viewer');

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read own roles" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;

-- Attendance status enum
CREATE TYPE public.attendance_status AS ENUM ('present','absent','late','excused');

-- Departments
CREATE TABLE public.departments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT UNIQUE NOT NULL,
  code TEXT UNIQUE NOT NULL,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.departments TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.departments TO authenticated;
GRANT ALL ON public.departments TO service_role;
ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "view departments" ON public.departments FOR SELECT TO authenticated USING (true);
CREATE POLICY "admin manage departments" ON public.departments FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- Teachers
CREATE TABLE public.teachers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  specialty TEXT,
  photo_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.teachers TO authenticated;
GRANT ALL ON public.teachers TO service_role;
ALTER TABLE public.teachers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "view teachers" ON public.teachers FOR SELECT TO authenticated USING (true);
CREATE POLICY "admin manage teachers" ON public.teachers FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- Courses
CREATE TABLE public.courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  department_id UUID NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  semester SMALLINT NOT NULL CHECK (semester BETWEEN 1 AND 8),
  name TEXT NOT NULL,
  code TEXT,
  teacher_id UUID REFERENCES public.teachers(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON public.courses (department_id, semester);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.courses TO authenticated;
GRANT ALL ON public.courses TO service_role;
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "view courses" ON public.courses FOR SELECT TO authenticated USING (true);
CREATE POLICY "admin manage courses" ON public.courses FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- Students
CREATE TABLE public.students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_no TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  gender TEXT,
  department_id UUID NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  semester SMALLINT NOT NULL CHECK (semester BETWEEN 1 AND 8),
  class_code TEXT,
  phone TEXT,
  email TEXT,
  photo_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON public.students (department_id, semester);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.students TO authenticated;
GRANT ALL ON public.students TO service_role;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
CREATE POLICY "view students" ON public.students FOR SELECT TO authenticated USING (true);
CREATE POLICY "admin manage students" ON public.students FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- Attendance
CREATE TABLE public.attendance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  course_id UUID NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
  teacher_id UUID REFERENCES public.teachers(id) ON DELETE SET NULL,
  date DATE NOT NULL,
  status public.attendance_status NOT NULL,
  remarks TEXT,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (student_id, course_id, date)
);
CREATE INDEX ON public.attendance (course_id, date);
CREATE INDEX ON public.attendance (student_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.attendance TO authenticated;
GRANT ALL ON public.attendance TO service_role;
ALTER TABLE public.attendance ENABLE ROW LEVEL SECURITY;
CREATE POLICY "view attendance" ON public.attendance FOR SELECT TO authenticated USING (true);
CREATE POLICY "admin manage attendance" ON public.attendance FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- Seed departments (14)
INSERT INTO public.departments (name, code) VALUES
 ('Computer Science','CS'),
 ('Accounting and Finance','ACC'),
 ('Sharia and Islamic Studies','SHR'),
 ('Social Work','SWK'),
 ('Public Administration','BPA'),
 ('Veterinary Science','VET'),
 ('Nursing','NUR'),
 ('Clinical Medicine','BCO'),
 ('Public Health','BPH'),
 ('Human Resource Management','HRM'),
 ('Nutrition','NUT'),
 ('Midwifery','MID'),
 ('Economics','ECO'),
 ('Education','EDU');

-- Seed teachers
INSERT INTO public.teachers (full_name, email, phone, specialty) VALUES
 ('Sheikh Adan','sheikh.adan@eau.edu.so','+252611000001','Islamic Studies'),
 ('Eng. Abdifatah Gaata','abdifatah.gaata@eau.edu.so','+252611000002','Web Development'),
 ('Eng. Daud Nuux','daud.nuux@eau.edu.so','+252611000003','Linux OS'),
 ('Mr. Mohamed Isxaaq','mohamed.isxaaq@eau.edu.so','+252611000004','Research Methodology'),
 ('Mr. Abshir Gurey','abshir.gurey@eau.edu.so','+252611000005','Computer Hardware');

-- Seed BCS 8 students (Computer Science, semester 8)
WITH d AS (SELECT id FROM public.departments WHERE code = 'CS')
INSERT INTO public.students (student_no, full_name, department_id, semester, class_code, gender)
SELECT 'CS8-' || LPAD(row_number() OVER ()::text, 3, '0'),
       name,
       (SELECT id FROM d),
       8,
       'BCS8',
       CASE WHEN split_part(name,' ',1) IN ('Aisha','Aisho','Amino','Deko','Fadumo','Fahimo','Faiso','Hafso','Hawo','Hibaq','Khadro','Maryan','Rodo','Sabirin','Sahro','Sainab','Salma','Salmo','Sumayo') THEN 'F' ELSE 'M' END
FROM (VALUES
 ('Abdiaziz Ali Ainab Ahmed'),('Abdikani Yusuf Daad Isse'),('Abdinasir Gulled Jama Mohamud'),
 ('Abdirahman Abdikarim Hassan'),('Abdirahman Abdirashid Yusuf Muse'),('Abdirahman Mahad Aw-Abdi Samatar'),
 ('Abdishakur Abdullahi Said Muse'),('Abdullahi Hared Mohamed Abdi'),('Abdullahi Mohamed Hared Hirad'),
 ('Abdullahi Muse Abdi Ali'),('Ahmed Abdullahi Mohamud Abdi'),('Aisha Mohamed Omar Mohamed'),
 ('Aisho Abdirahman Osman Samater'),('Amino Abdullahi Yusuf Muse'),('Deko Abdihakin Waberi Mohamed'),
 ('Fadumo Liban Barre Mohamud'),('Fahimo Mohamed Abdi Ahmed'),('Faiso Abdirashid Mohamud Said'),
 ('Fuad Mohamed Ali Osman'),('Hafso Abdisamad Dahir Ahmed'),('Hawo Osman Mohamud Farah'),
 ('Hibaq Yasin Mohamed Omar'),('Khadar Said Nur'),('Khadro Liban Jama Rabah'),
 ('Maryan Osman Omar Yusuf Mohamud'),('Mohamed Ahmed Ali Salah'),('Mohamed Ali Mohamed Farah'),
 ('Mohamed Faysal Buh Nur'),('Mohamed Liban Ahmed Said'),('Mohamed Mohamud Hared Hassan'),
 ('Mohamed Said Mohamed Osman'),('Osman Mire Hussein Ahmed'),('Rodo Abdi Mohamud Barre'),
 ('Sabirin Ali Thabit'),('Sahro Dahir Khalid Aw Muse'),('Said Mohamed Abdisalan'),
 ('Said Mohamed Said'),('Sainab Mohamud Mohamed Farah'),('Salma Abdullahi Hussein'),
 ('Salmo Abdirisak Ali Mohamud'),('Sekeriye Mohamed Muse Shire'),('Suheyb Faysal Mohamed Ahmed'),
 ('Sumayo Isse Abdikarim Ali'),('Yahye Osman Said Abdi')
) AS t(name);

-- Seed BCS 6 students (Computer Science, semester 6)
WITH d AS (SELECT id FROM public.departments WHERE code = 'CS')
INSERT INTO public.students (student_no, full_name, department_id, semester, class_code, gender)
SELECT 'CS6-' || LPAD(row_number() OVER ()::text, 3, '0'),
       name,
       (SELECT id FROM d),
       6,
       'BCS6',
       CASE WHEN split_part(name,' ',1) IN ('Adno','Aisho','Balqiiso','Dahabo','Fadumo','Fardows','Fartun','Hafso','Halimo','Khadro','Muhubo','Muno','Nadiro','Ruweydo','Sahro','Samsam','Shukri') THEN 'F' ELSE 'M' END
FROM (VALUES
 ('Abdikarim Said Abdi'),('Abdimajid Abdirashid Yasin Mohamed'),('Abdirahman Abdullahi Ali'),
 ('Abdirahman Khalid Mohamed Abdi'),('Abdirahman Mohamed Ahmed'),('Abdirahman Mohamed Ali'),
 ('Shirwa Abdirahman Mohamed Omar'),('Abdiweli Abdirahman Ali'),('Abdiweli Jama Hassan Khalif'),
 ('Abdullahi Mohamed Ahmed'),('Abdullahi Mohamed Omar Mohamed'),('Abshir Abdiasis Muse Mohamed'),
 ('Adno Abdullahi Ali Mohamud'),('Adno Adam Khalid Aw Muse'),('Ahmed Khadar Said Bashil'),
 ('Ahmed Said Ahmed Ali'),('Aisho Abdirisak Muse Artan'),('Aisho Mohamed Muse Hassan'),
 ('Aisho Mohamud Mohamed Ali'),('Balqiiso Jama Elmi'),('Dahabo Abdullahi Isse Farah'),
 ('Fadumo Abdullahi Muse Isse'),('Fadumo Said Abdullahi Mohamud'),('Farah Abdikarim Adam Mohamud'),
 ('Fardows Farah Ismail Yusuf'),('Fartun Ahmed Osman Ali'),('Hafso Nur Yusuf Ali'),
 ('Halimo Abdirisak Ismail Mohamed'),('Ibrahim Abdi Ali Mohamud'),('Ismail Abdirisak Omar Abdi'),
 ('Jabir Mohamed Ibrahim Ali'),('Khadar Abdullahi Salah Mohamed'),('Khadro Abdirisak Abdi Mohamed'),
 ('Mohamed Abdiasis Omar Ahmed'),('Mohamed Abdifatah Yasin Ibrahim'),('Mohamed Ahmed Abshir Hussein'),
 ('Mohamed Ismail Mohamud Abdi'),('Mohuyadin Awil Abdi Mohamud'),('Muhubo Mohamed Said Ali'),
 ('Muno Mohamed Ahmed Mohamed'),('Muse Abdullahi Muse Gelle'),('Nadiro Mohamud Mohamed Ali'),
 ('Ruweydo Abdinasir Mohamud'),('Sahro Ali Abdalle Mohamed'),('Said Abshir Mohamud'),
 ('Samsam Khalif Osman Shibbin'),('Shukri Mohamed Hirsi Mohamud'),('Yacqub Abdinur Gelle Mohamed'),
 ('Yusuf Ahmed Ismail Mohamed'),('Luqman Abdi Ahmed'),('Mohamed Ahmed Yusuf')
) AS t(name);

-- Seed courses (Computer Science, all 8 semesters, per curriculum + Jan 2026 timetable)
WITH d AS (SELECT id FROM public.departments WHERE code='CS'),
     t_islam AS (SELECT id FROM public.teachers WHERE full_name='Sheikh Adan'),
     t_web AS (SELECT id FROM public.teachers WHERE full_name='Eng. Abdifatah Gaata'),
     t_lin AS (SELECT id FROM public.teachers WHERE full_name='Eng. Daud Nuux'),
     t_res AS (SELECT id FROM public.teachers WHERE full_name='Mr. Mohamed Isxaaq'),
     t_hw AS (SELECT id FROM public.teachers WHERE full_name='Mr. Abshir Gurey')
INSERT INTO public.courses (department_id, semester, name, teacher_id)
SELECT (SELECT id FROM d), sem, cname, tid FROM (VALUES
 (1,'Islamic Studies',(SELECT id FROM t_islam)),
 (1,'English Skills',NULL),
 (1,'Mathematics',NULL),
 (1,'Computer Application',NULL),
 (1,'Introduction to Computer',NULL),
 (2,'Introduction to Programming',NULL),
 (2,'English Composition',NULL),
 (2,'Calculus',NULL),
 (2,'Physics',NULL),
 (2,'Arabic Language',NULL),
 (2,'Operating System',NULL),
 (3,'English Skills',NULL),
 (3,'Computer Hardware',(SELECT id FROM t_hw)),
 (3,'Intro to Programming',NULL),
 (3,'Operating System',NULL),
 (3,'Basic Networking',NULL),
 (3,'DLD',NULL),
 (4,'Discrete Mathematics',NULL),
 (4,'Database Management System',NULL),
 (4,'Human Computer Interaction',NULL),
 (4,'Fundamentals of Web Development I',(SELECT id FROM t_web)),
 (4,'Islamic Studies',(SELECT id FROM t_islam)),
 (5,'Server Administration',NULL),
 (5,'Computer Graphics',NULL),
 (5,'Linear Algebra',NULL),
 (5,'Somali Culture',NULL),
 (5,'SQL',NULL),
 (5,'Research Methodology',(SELECT id FROM t_res)),
 (6,'Advance Java',NULL),
 (6,'Mobile Computing and Applications',NULL),
 (6,'Networking Security',NULL),
 (6,'Artificial Intelligence',NULL),
 (6,'Managing Cyber Security',NULL),
 (7,'Mobile Application',NULL),
 (7,'Islamic Studies',(SELECT id FROM t_islam)),
 (7,'IP Routing',NULL),
 (7,'Cyber Security',NULL),
 (7,'Linux OS',(SELECT id FROM t_lin)),
 (8,'C#',NULL),
 (8,'ASP.NET',(SELECT id FROM t_web)),
 (8,'Theory of Computation',NULL),
 (8,'Research Methodology',(SELECT id FROM t_res))
) AS c(sem, cname, tid);

-- Seed courses for other departments (base curriculum per semester)
INSERT INTO public.courses (department_id, semester, name)
SELECT d.id, s.sem, s.name
FROM public.departments d
CROSS JOIN (VALUES
 (1,'Islamic Studies'),(1,'English Skills'),(1,'Mathematics'),(1,'Introduction to Field'),
 (2,'English Composition'),(2,'Arabic Language'),(2,'Communication Skills'),(2,'Core Subject II'),
 (3,'Probability and Statistics'),(3,'Communication Skills'),(3,'Islamic Studies'),(3,'Core Subject III'),
 (4,'Islamic Studies'),(4,'Research Foundations'),(4,'Advanced Core Subject'),(4,'Ethics'),
 (5,'Somali Culture'),(5,'Advanced Topic I'),(5,'Advanced Topic II'),(5,'Elective'),
 (6,'Research Methodology'),(6,'Advanced Topic III'),(6,'Field Practice'),(6,'Elective'),
 (7,'Advanced Topic IV'),(7,'Professional Ethics'),(7,'Practicum'),(7,'Elective'),
 (8,'Capstone Project'),(8,'Advanced Topic V'),(8,'Internship'),(8,'Elective')
) AS s(sem, name)
WHERE d.code <> 'CS';
