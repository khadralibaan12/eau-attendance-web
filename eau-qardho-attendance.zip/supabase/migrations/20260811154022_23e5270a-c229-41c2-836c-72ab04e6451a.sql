ALTER TABLE public.teachers ADD COLUMN IF NOT EXISTS user_id uuid;
CREATE UNIQUE INDEX IF NOT EXISTS teachers_user_id_key ON public.teachers(user_id) WHERE user_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS attendance_date_idx ON public.attendance(date);

-- Aggregated class history: month/day/course counts computed in the database
CREATE OR REPLACE FUNCTION public.attendance_class_history(p_dept uuid, p_sem smallint)
RETURNS TABLE (day date, course_id uuid, course_name text, present bigint, absent bigint)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT a.date AS day,
         c.id AS course_id,
         c.name AS course_name,
         count(*) FILTER (WHERE a.status = 'present') AS present,
         count(*) FILTER (WHERE a.status = 'absent') AS absent
  FROM public.attendance a
  JOIN public.courses c ON c.id = a.course_id
  WHERE c.department_id = p_dept AND c.semester = p_sem
  GROUP BY a.date, c.id, c.name
  ORDER BY a.date DESC, c.name
$$;
GRANT EXECUTE ON FUNCTION public.attendance_class_history(uuid, smallint) TO authenticated;

-- Per-student attendance summary by course
CREATE OR REPLACE FUNCTION public.student_attendance_summary(p_student uuid)
RETURNS TABLE (course_id uuid, course_name text, teacher_name text, present bigint, absent bigint)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT c.id, c.name, t.full_name,
         count(*) FILTER (WHERE a.status = 'present'),
         count(*) FILTER (WHERE a.status = 'absent')
  FROM public.attendance a
  JOIN public.courses c ON c.id = a.course_id
  LEFT JOIN public.teachers t ON t.id = c.teacher_id
  WHERE a.student_id = p_student
  GROUP BY c.id, c.name, t.full_name
  ORDER BY c.name
$$;
GRANT EXECUTE ON FUNCTION public.student_attendance_summary(uuid) TO authenticated;
