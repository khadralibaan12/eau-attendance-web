import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const coursesCatalogueOptions = (userId: string) => queryOptions({
  queryKey: ["catalogue", "courses", userId],
  queryFn: async () => {
    const [departments, courses, teachers] = await Promise.all([
      supabase.from("departments").select("id, name, code").order("name"),
      supabase.from("courses").select("id, name, code, semester, department_id, teacher_id, credit_hours, teachers(full_name)").order("semester").order("name"),
      supabase.from("teachers").select("id, full_name").order("full_name"),
    ]);
    const error = departments.error ?? courses.error ?? teachers.error;
    if (error) throw error;
    return { depts: departments.data ?? [], rows: courses.data ?? [], teachers: teachers.data ?? [] };
  },
});

export const teachersCatalogueOptions = (userId: string) => queryOptions({
  queryKey: ["catalogue", "teachers", userId],
  queryFn: async () => {
    const [teachers, courses, assignments, departments] = await Promise.all([
      supabase.from("teachers").select("id, full_name, email, phone, specialty, user_id").order("full_name"),
      supabase.from("courses").select("id, name, semester, teacher_id, department_id").order("semester").order("name"),
      supabase.from("lecturer_courses").select("lecturer_id, course_id"),
      supabase.from("departments").select("id, code"),
    ]);
    const error = teachers.error ?? courses.error ?? assignments.error ?? departments.error;
    if (error) throw error;
    const codes = new Map((departments.data ?? []).map(d => [d.id, d.code]));
    return (teachers.data ?? []).map(teacher => {
      const ids = new Set((assignments.data ?? []).filter(a => a.lecturer_id === teacher.id).map(a => a.course_id));
      return { ...teacher, assignedCourses: (courses.data ?? []).filter(c => c.teacher_id === teacher.id || ids.has(c.id)).map(c => ({ ...c, departmentCode: codes.get(c.department_id) ?? "" })) };
    });
  },
});