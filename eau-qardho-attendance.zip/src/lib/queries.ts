import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

// Shared, cached reads. Cached across route changes so navigating between
// pages is instant instead of refetching the same lists every time.
export function useDepartments() {
  return useQuery({
    queryKey: ["departments"],
    staleTime: 10 * 60_000,
    queryFn: async () => {
      const { data } = await supabase.from("departments").select("*").order("name");
      return data ?? [];
    },
  });
}

export function useDashboardStats() {
  return useQuery({
    queryKey: ["dashboard-stats"],
    staleTime: 5 * 60_000,
    queryFn: async () => {
      const [d, t, s, c] = await Promise.all([
        supabase.from("departments").select("id", { count: "exact", head: true }),
        supabase.from("teachers").select("id", { count: "exact", head: true }),
        supabase.from("students").select("id", { count: "exact", head: true }),
        supabase.from("courses").select("id", { count: "exact", head: true }),
      ]);
      return { departments: d.count, teachers: t.count, students: s.count, courses: c.count };
    },
  });
}

export function useCurrentRole() {
  return useQuery({
    queryKey: ["current-role"],
    staleTime: 10 * 60_000,
    queryFn: async () => {
      const { data: session } = await supabase.auth.getSession();
      const uid = session.session?.user.id;
      if (!uid) return { role: "viewer" as const, userId: null as string | null };
      const { data } = await supabase.from("user_roles").select("role").eq("user_id", uid);
      const roles = (data ?? []).map((r: any) => r.role as string);
      return {
        role: (roles.includes("admin") ? "admin" : roles.includes("teacher") ? "teacher" : "viewer") as
          | "admin"
          | "teacher"
          | "viewer",
        userId: uid,
      };
    },
  });
}
