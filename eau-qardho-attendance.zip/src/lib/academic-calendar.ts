// EAU Qardho Academic Calendar 2026-2027 (official PDF).
export type CalendarEvent = { start: string; end: string; activity: string };

export const ACADEMIC_YEAR = "2026-2027";

export const ACADEMIC_CALENDAR: { semester: string; events: CalendarEvent[] }[] = [
  {
    semester: "Semester One",
    events: [
      { start: "2026-09-01", end: "2026-09-01", activity: "Registration for new students starts" },
      { start: "2026-09-19", end: "2026-09-19", activity: "Classes start" },
      { start: "2026-10-10", end: "2026-10-17", activity: "Re-exams" },
      { start: "2026-11-07", end: "2026-11-12", activity: "Midterm examinations" },
      { start: "2027-01-13", end: "2027-01-15", activity: "Home study days" },
      { start: "2027-01-16", end: "2027-01-23", activity: "Final examinations" },
    ],
  },
  {
    semester: "Semester Two",
    events: [
      { start: "2027-02-01", end: "2027-02-01", activity: "Classes start" },
      { start: "2027-02-13", end: "2027-02-18", activity: "Re-exams week" },
      { start: "2027-03-01", end: "2027-03-09", activity: "Midterm examinations" },
      { start: "2027-03-10", end: "2027-03-12", activity: "Eid holidays" },
      { start: "2027-03-13", end: "2027-03-13", activity: "Classes start (after Eid)" },
      { start: "2027-05-19", end: "2027-05-27", activity: "Eid and home study holidays" },
      { start: "2027-05-29", end: "2027-06-05", activity: "Final examinations" },
    ],
  },
];

export function eventStatus(e: CalendarEvent, today = new Date().toISOString().slice(0, 10)) {
  if (today > e.end) return "done";
  if (today >= e.start) return "now";
  return "upcoming";
}

export function formatRange(e: CalendarEvent) {
  const f = (d: string) => new Date(d + "T00:00:00").toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
  return e.start === e.end ? f(e.start) : `${f(e.start)} – ${f(e.end)}`;
}
