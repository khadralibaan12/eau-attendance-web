// User-supplied October 2026 teaching roster; course names match existing records.
const groups: [string, number, [string, string][]][] = [
  ["BCS", 3, [
    ["Basic Networking", "Abdifatah Said Gataa"],
    ["Computer Architecture and Organization", "Abshir Gurey"],
    ["English Language Skills", "Patrick"],
    ["Introduction to Programming Languages", "Abdifatah Said Gataa"],
    ["Probability and Statistics", "Fardows Nadif"],
  ]],
  ["BCS", 5, [
    ["Computer Graphics", "Abdullahi Ahmed"], ["Core Java", "Abdifatah Said Gataa"],
    ["Data Structures and Algorithms", "Abdifatah Said Gataa"],
    ["Database Management System", "Abdullahi Ahmed"],
    ["Discrete Mathematics", "Sharmarke"], ["Software Engineering", "Abshir Gurey"],
  ]],
  ["BCS", 7, [
    ["Computing, Society and Ethics", "Abdullahi Ahmed"],
    ["IP Routing and Switching", "Abdifatah Said Gataa"],
    ["Managing Cyber Security Operations", "Abdifatah Said Gataa"],
    ["Mobile Application", "Abdullahi Ahmed"], ["Multimedia", "Abdullahi Ahmed"],
    ["Research Methodology", "Mohamed Is-haq Abdullahi"],
  ]],
  ["BBA", 3, [
    ["English Language Skills", "Patrick"], ["Financial Accounting I", "Abdihafid Farah"],
    ["Organizational Behavior and Leadership", "Abdullahi Abdihakin"],
    ["Principles of Marketing", "Ali Dahir"], ["Probability and Statistics", "Fardows Nadif"],
  ]],
  ["BBA", 5, [
    ["Computerized Accounting", "Abdihafid Farah"], ["Cost Accounting", "Mohamed Abdi"],
    ["Entrepreneurship", "Ali Dahir"], ["Financial Accounting III", "Mohamed Abdi"],
    ["Principles of Macroeconomics", "Fardows Nadif"], ["Principles of Taxation", "Abdihafid Farah"],
  ]],
  ["BBA", 7, [
    ["Audit and Assurance I", "Mohamed Abdi"], ["Business Law", "Mohamed Is-haq Abdullahi"],
    ["Governmental Accounting", "Abdihafid Farah"], ["Managerial Accounting", "Mohamed Abdi"],
    ["Public Finance", "Fardows Nadif"], ["Research Methodology", "Mustafe Aware"],
  ]],
  ["BNUR", 3, [
    ["Biochemistry I", "Dr. Kareri"], ["Cytology and Histology", "Dr. Najmo Abdirisak"],
    ["English Language Skills", "Patrick"], ["Fundamentals of Pathology", "Dr. Saynab"],
    ["Medical English", "Abdullahi Arshe"],
  ]],
  ["BNUR", 5, [
    ["Communicable & Non C. Diseases", "Naimo"],
    ["Introduction to Embryology", "Dr. Najmo Abdirisak"],
    ["Medical and Surgical Nursing I", "Abdullahi Arshe"],
    ["Microbiology and Immunology", "Dr. Saynab"],
    ["Nutrition in Health and Illness", "Asia Abdishakur"],
    ["Obstetrics and Gynecology I", "Dr. Najmo Abdirisak"],
  ]],
  ["BNUR", 7, [
    ["Clinical Leadership", "Asia Abdishakur"], ["Community Nursing", "Asia Gabbac"],
    ["Health Assessment", "Asia Gabbac"], ["Pediatric Nursing II", "Dr. Abdihakin Ainab"],
    ["Pre-operative Nursing", "Abdullahi Arshe"], ["Research Methodology", "Wadaag 1"],
  ]],
  ["BCO", 7, [
    ["General Surgery II", "Dr. Ibrahim"], ["Health and Professional Ethics", "Asia Abdishakur"],
    ["Introduction to Clinical Officer", "Asia Gabbac"],
    ["Obstetrics and Gynecology II", "Dr. Najmo Abdirisak"],
    ["Psychiatry", "Dr. Ibrahim"], ["Research Methodology", "Mustafe Aware"],
  ]],
  ["BVET", 5, [
    ["Animal Nutrition & Feeding", "Dr. Abdinur Sayah"], ["Immunology & Molecular Biology", "Dr. Kareri"],
    ["Islamic Studies", "Sh. Mohamud Isse Shire"], ["Veterinary General Pathology", "Dr. Kareri"],
    ["Veterinary Microbiology", "Dr. Kareri"], ["Veterinary Parasitology", "Dr. Abdinur Sayah"],
  ]],
  ["SHR", 5, [
    ["Axadith Al-Axkam 3", "Sh. Mohamud Isse Shire"], ["Ayat Al-Axkam 3", "Sh.Abdirisak Khalid"],
    ["English Language Skills", "Mohamed Is-haq Abdullahi"], ["Fiqhi Al-Mucamalat I", "Sh. Yusuf"],
    ["Fiqhi Al-Muqaran I", "Sh. Yusuf"], ["Fiqhi Al-Usrah", "Sh. Yusuf"],
    ["Usulu Fiqhi 3", "Dr. Musdafe"], ["Xaadar Al-Caalam Al-Islami", "Sh. Mohamud Isse Shire"],
  ]],
];

export const teachingImport = groups.flatMap(([department, semester, pairs]) =>
  pairs.map(([course, teacher]) => ({
    department, semester, course, teacher,
    creditHours: semester === 3 && course === "English Language Skills" ? 6 : 4,
  })),
);