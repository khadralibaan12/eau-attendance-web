import { z } from "zod";
import { monthRange } from "./monthly-report";

export const assistantInput = z.object({
  question: z.string().trim().min(1, "Question is required").max(1000, "Question is too long"),
  scope: z.object({
    departmentId: z.string().uuid().optional(),
    semester: z.number().int().min(1).max(8).optional(),
    courseId: z.string().uuid().optional(),
    month: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/).optional(),
  }).optional(),
});
export type AssistantScope = z.infer<typeof assistantInput>["scope"];

export function assistantFilters(scope: AssistantScope) {
  const range = scope?.month ? monthRange(scope.month) : undefined;
  return {
    p_dept: scope?.departmentId, p_sem: scope?.semester, p_course: scope?.courseId,
    p_from: range?.from, p_to: range?.to,
  };
}