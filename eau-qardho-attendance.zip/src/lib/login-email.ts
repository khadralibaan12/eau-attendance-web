import { z } from "zod";

export function loginEmail(identifier: string, mode: "admin" | "teacher") {
  const value = identifier.trim().toLowerCase();
  if (mode === "teacher") {
    if (!z.string().email().safeParse(value).success) throw new Error("Enter your teacher email address.");
    return value;
  }
  return value.includes("@") ? value : `${value}@eau.local`;
}