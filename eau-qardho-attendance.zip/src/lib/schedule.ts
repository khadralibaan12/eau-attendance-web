// Official class schedule (working hours) for EAU Gardo.
export const CLASS_START = "16:30"; // 4:30 PM
export const CLASS_END = "21:20"; // 9:20 PM
export const CLASS_TIME_LABEL = "4:30 PM – 9:20 PM";

function minutes(t: string) {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
}

/** Length of one class session in hours (4h 50m = 4.83). */
export const HOURS_PER_CLASS = (minutes(CLASS_END) - minutes(CLASS_START)) / 60;

/** Present days × session length, rounded to 1 decimal. */
export function attendedHours(presentDays: number) {
  return Math.round(presentDays * HOURS_PER_CLASS * 10) / 10;
}
