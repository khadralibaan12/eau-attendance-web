import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

// Generate N sample students for a department/semester (admin only)
const FIRST_NAMES_M = [
  "Ahmed","Mohamed","Abdi","Ali","Osman","Yusuf","Hassan","Hussein","Ibrahim","Ismail",
  "Farah","Said","Mahamud","Abdirahman","Abdullahi","Abdirisak","Mustafa","Khalid","Nur","Warsame",
];
const FIRST_NAMES_F = [
  "Khadra","Fadumo","Amino","Hawo","Sahra","Deko","Hodan","Muno","Ifrah","Farhia",
  "Halimo","Ubah","Rahma","Zamzam","Nasteeho","Naima","Sagal","Ayan","Idil","Anisa",
];
const MIDDLE_NAMES = ["Ali","Mohamed","Abdi","Yusuf","Ahmed","Hassan","Hussein","Ibrahim","Farah","Said","Osman","Khalid","Nur","Abdullahi","Mahamud"];
const LAST_NAMES = ["Jama","Warsame","Barre","Farah","Ahmed","Mohamud","Aden","Elmi","Isse","Samatar","Guled","Roble","Dahir","Nur","Yusuf"];

function randomName(gender: "M" | "F") {
  const first = gender === "M"
    ? FIRST_NAMES_M[Math.floor(Math.random() * FIRST_NAMES_M.length)]
    : FIRST_NAMES_F[Math.floor(Math.random() * FIRST_NAMES_F.length)];
  const middle = MIDDLE_NAMES[Math.floor(Math.random() * MIDDLE_NAMES.length)];
  const last = LAST_NAMES[Math.floor(Math.random() * LAST_NAMES.length)];
  return `${first} ${middle} ${last}`;
}

export const generateStudents = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { departmentId: string; semester: number; count: number; deptCode: string }) => d)
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
    if (!isAdmin) throw new Error("Only administrators can add students");
    if (!(data.count >= 1 && data.count <= 200)) throw new Error("Count must be between 1 and 200");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { count: existingCount } = await supabaseAdmin
      .from("students")
      .select("*", { count: "exact", head: true })
      .eq("department_id", data.departmentId)
      .eq("semester", data.semester);

    const rows = Array.from({ length: data.count }, (_, i) => {
      const gender = Math.random() < 0.5 ? "M" : "F";
      const seq = (existingCount ?? 0) + i + 1;
      return {
        student_no: `${data.deptCode}${data.semester}-${String(seq).padStart(4, "0")}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`,
        full_name: randomName(gender),
        gender,
        department_id: data.departmentId,
        semester: data.semester,
        class_code: `${data.deptCode}${data.semester}`,
      };
    });
    const { error } = await supabaseAdmin.from("students").insert(rows);
    if (error) throw new Error(error.message);
    return { inserted: rows.length };
  });