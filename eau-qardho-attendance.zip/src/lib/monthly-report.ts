export function monthRange(month: string) {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) throw new Error("Invalid report month");
  const [year, number] = month.split("-").map(Number);
  const days = new Date(Date.UTC(year, number, 0)).getUTCDate();
  return { from: `${month}-01`, to: `${month}-${days}` };
}

export type MonthlyStudent = {
  id: string; full_name: string; student_no: string; department_id: string;
  semester: number; class_code?: string | null; departments: { name: string } | null;
};

export type StudentReport = {
  student_id: string; student_name: string; student_no: string; department_id: string;
  department_name: string; semester: number; present: number; absent: number; total: number; pct: number | null;
};

export function includeMonthlyRoster(students: MonthlyStudent[], stats: StudentReport[], classCode = "", semester = ""): StudentReport[] {
  const byId = new Map(stats.map((row) => [row.student_id, row]));
  return students.filter((student) => (!classCode || student.class_code === classCode) && (!semester || student.semester === Number(semester))).map((student) => byId.get(student.id) ?? {
    student_id: student.id, student_name: student.full_name, student_no: student.student_no,
    department_id: student.department_id, department_name: student.departments?.name ?? "",
    semester: student.semester, present: 0, absent: 0, total: 0, pct: null,
  });
}

export type ClassAttendance = {
  date: string; status: string; course_id: string;
  courses: { name: string; teachers: { full_name: string } | null } | null;
};

export function classReportStats(records: ClassAttendance[]) {
  const days = new Map<string, { day: string; present: number; absent: number; total: number; pct: number }>();
  const courses = new Map<string, { course_id: string; course_name: string; teacher_name: string | null; present: number; absent: number; total: number; pct: number }>();
  for (const record of records) {
    const day = days.get(record.date) ?? { day: record.date, present: 0, absent: 0, total: 0, pct: 0 };
    const course = courses.get(record.course_id) ?? { course_id: record.course_id, course_name: record.courses?.name ?? "", teacher_name: record.courses?.teachers?.full_name ?? null, present: 0, absent: 0, total: 0, pct: 0 };
    for (const row of [day, course]) {
      row.present += record.status === "present" ? 1 : 0;
      row.absent += record.status === "absent" ? 1 : 0;
      row.total += 1;
      row.pct = Math.round(row.present / row.total * 1000) / 10;
    }
    days.set(record.date, day);
    courses.set(record.course_id, course);
  }
  return { daily: [...days.values()].sort((a, b) => a.day.localeCompare(b.day)), courses: [...courses.values()] };
}