import { ACADEMIC_CALENDAR } from "./academic-calendar";

export type Period = "daily" | "weekly" | "monthly" | "semester";
export const MAX_MARKS = 10;

const iso = (d: Date) => d.toISOString().slice(0, 10);
const parse = (s: string) => new Date(s + "T00:00:00Z");

/** Semester ranges from the academic calendar: first "Classes start" → last final-exam day. */
export function semesterRanges() {
  return ACADEMIC_CALENDAR.map((s) => ({
    name: s.semester,
    start: s.events.find((e) => e.activity.startsWith("Classes start"))!.start,
    end: s.events[s.events.length - 1].end,
  }));
}

/** Date range covered by a period around `date`. Weeks start on Saturday. */
export function periodRange(period: Period, date: string): { from: string; to: string; label: string } {
  const d = parse(date);
  if (period === "daily") return { from: date, to: date, label: date };
  if (period === "weekly") {
    const back = (d.getUTCDay() + 1) % 7; // Saturday = 0
    const start = new Date(d.getTime() - back * 86400000);
    const end = new Date(start.getTime() + 6 * 86400000);
    return { from: iso(start), to: iso(end), label: `${iso(start)} – ${iso(end)}` };
  }
  if (period === "monthly") {
    const start = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1));
    const end = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0));
    return { from: iso(start), to: iso(end), label: start.toLocaleDateString("en-GB", { month: "long", year: "numeric", timeZone: "UTC" }) };
  }
  const sems = semesterRanges();
  const s = sems.find((x) => date >= x.start && date <= x.end) ?? sems.find((x) => date < x.start) ?? sems[sems.length - 1];
  return { from: s.start, to: s.end, label: `${s.name} (${s.start} – ${s.end})` };
}

/**
 * Each class held counts the course's credit hours.
 * Present/late = attended. Excused classes are left out of the total.
 * Marks = attended hours / possible hours × 10.
 */
export function calcStudent(statuses: string[], creditHours: number) {
  const present = statuses.filter((s) => s === "present" || s === "late").length;
  const absent = statuses.filter((s) => s === "absent").length;
  const excused = statuses.filter((s) => s === "excused").length;
  const counted = present + absent;
  const attendedHours = present * creditHours;
  const possibleHours = counted * creditHours;
  const pct = counted ? Math.round((present / counted) * 1000) / 10 : 0;
  const marks = counted ? Math.round((attendedHours / possibleHours) * MAX_MARKS * 10) / 10 : 0;
  return { present, absent, excused, attendedHours, possibleHours, pct, marks };
}
