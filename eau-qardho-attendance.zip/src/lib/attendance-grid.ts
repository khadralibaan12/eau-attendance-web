export const CLASS_DAYS_PER_WEEK = 5;
export const ATTENDANCE_SHEET_WEEKS = 4;
export const ATTENDANCE_SHEET_PERIODS = 4;

/** Preserve Saturday-based weeks, including partial weeks at either month boundary. */
export function buildAttendanceGrid(month: string): (string | null)[][] {
  if (!/^\d{4}-\d{2}$/.test(month)) return [];
  const [year, m] = month.split("-").map(Number);
  if (m < 1 || m > 12) return [];
  const weeks: string[][] = [];
  let current: string[] = [];
  const last = new Date(year, m, 0).getDate();
  for (let day = 1; day <= last; day++) {
    const weekday = new Date(year, m - 1, day).getDay();
    if (weekday === 6 && current.length) { weeks.push(current); current = []; }
    if (weekday === 6 || weekday <= 3) current.push(`${month}-${String(day).padStart(2, "0")}`);
  }
  if (current.length) weeks.push(current);
  return weeks.map((week) => Array.from({ length: CLASS_DAYS_PER_WEEK }, (_, p) => week[p] ?? null));
}

/** Fixed sheet layout; the full calendar remains available without deleting records. */
export function buildAttendanceSheetGrid(month: string): (string | null)[][] {
  const weeks = buildAttendanceGrid(month);
  return Array.from({ length: ATTENDANCE_SHEET_WEEKS }, (_, w) =>
    Array.from({ length: ATTENDANCE_SHEET_PERIODS }, (_, p) => weeks[w]?.[p] ?? null),
  );
}

export function classDayLabel(date: string): string {
  return new Date(`${date}T12:00:00`).toLocaleDateString("en", { weekday: "short" });
}