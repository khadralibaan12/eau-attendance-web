import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

// Creates (or updates) a login account for a teacher. Admin only.
export const upsertTeacherLogin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { teacherId: string; email: string; password: string }) => {
    if (!d.teacherId) throw new Error("Missing teacher");
    if (!d.email?.includes("@")) throw new Error("A valid email is required");
    if (!d.password || d.password.length < 6) throw new Error("Password must be at least 6 characters");
    return d;
  })
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Only administrators can manage teacher logins");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const email = data.email.trim().toLowerCase();

    const { data: list } = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 1000 });
    let user = list?.users.find((u) => u.email?.toLowerCase() === email);

    if (user) {
      await supabaseAdmin.auth.admin.updateUserById(user.id, { password: data.password });
    } else {
      const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
        email,
        password: data.password,
        email_confirm: true,
      });
      if (error) throw new Error(error.message);
      user = created.user ?? undefined;
    }
    if (!user) throw new Error("Could not create the teacher account");

    await supabaseAdmin
      .from("user_roles")
      .upsert({ user_id: user.id, role: "teacher" }, { onConflict: "user_id,role" });

    const { error: linkError } = await supabaseAdmin
      .from("teachers")
      .update({ user_id: user.id, email })
      .eq("id", data.teacherId);
    if (linkError) throw new Error(linkError.message);

    return { ok: true, email };
  });
