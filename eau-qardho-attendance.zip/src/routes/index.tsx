import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import eauLogo from "@/assets/eau-logo-fast.webp.asset.json";
import eauCampus from "@/assets/eau-campus-light.webp.asset.json";

const TITLE = "EAU Gardo Attendance System — East Africa University";
const DESC =
  "Attendance management for East Africa University – Gardo Campus: daily marking, monthly reports, credit-hour calculations and student history.";

export const Route = createFileRoute("/")({
  staticData: { sitemap: true },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://www.eauattendances.tech/" },
      { name: "twitter:card", content: "summary" },
      { name: "google-site-verification", content: "43ZyRirpDT2IoGNaPdLJ8NO6FOmKFiQNyptx-VOh-qY" },
    ],
    links: [{ rel: "canonical", href: "https://www.eauattendances.tech/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebApplication",
          name: "EAU Gardo Attendance System",
          url: "https://www.eauattendances.tech/",
          applicationCategory: "EducationalApplication",
          provider: { "@type": "CollegeOrUniversity", name: "East Africa University – Gardo Campus" },
        }),
      },
    ],
  }),
  component: Landing,
});

const FEATURES = [
  { t: "Attendance sheets", d: "Mark Present, Absent or Excused for every class across 4 weeks and 4 periods each month." },
  { t: "Monthly reports", d: "Filter by faculty, semester, class and course, then download Excel or PDF reports." },
  { t: "Credit-hour calculator", d: "Convert attendance into hours attended and a mark out of 10 for each student." },
  { t: "Student history", d: "Every saved record is stored permanently and can be reviewed per student and course." },
];

const FACULTIES = [
  "Business and Administration",
  "Information Science (Computer Science)",
  "Medicine and Health Science (Nursing, Clinical Officer)",
  "Agriculture and Veterinary Medicine",
  "Sharia",
];

function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border bg-card">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3">
          <div className="flex items-center gap-3">
            <img src={eauLogo.url} alt="East Africa University logo" width={40} height={40} className="h-10 w-10 object-contain" />
            <span className="font-semibold">EAU Gardo Attendance</span>
          </div>
          <Button asChild><Link to="/auth">Sign in</Link></Button>
        </div>
      </header>

      <main>
        <section className="relative overflow-hidden">
          <img src={eauCampus.url} alt="East Africa University Gardo campus" width={1280} height={853} fetchPriority="high" className="absolute inset-0 h-full w-full object-cover" />
          <div className="absolute inset-0 bg-primary/80" />
          <div className="relative mx-auto max-w-6xl px-4 py-20 sm:py-28 text-primary-foreground">
            <p className="text-sm font-semibold uppercase tracking-widest opacity-90">East Africa University – Gardo Campus</p>
            <h1 className="mt-3 max-w-3xl text-4xl font-bold leading-tight sm:text-5xl">Student attendance, recorded and reported in one place</h1>
            <p className="mt-4 max-w-2xl text-lg opacity-90">
              The official attendance system for teachers and administrators at EAU Gardo. Mark classes, track absences and produce monthly reports for every faculty.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg" variant="secondary"><Link to="/auth">Sign in to the system</Link></Button>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 py-16">
          <h2 className="text-3xl font-bold">What the system does</h2>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {FEATURES.map((f) => (
              <article key={f.t} className="rounded-lg border border-border bg-card p-5">
                <h3 className="font-semibold text-primary">{f.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{f.d}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="bg-muted">
          <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 md:grid-cols-2">
            <div>
              <h2 className="text-3xl font-bold">Faculties covered</h2>
              <ul className="mt-6 space-y-2">
                {FACULTIES.map((f) => (
                  <li key={f} className="rounded-md border-l-4 border-primary bg-card px-4 py-2">{f}</li>
                ))}
              </ul>
            </div>
            <div>
              <h2 className="text-3xl font-bold">Who uses it</h2>
              <p className="mt-6 text-muted-foreground">
                <strong className="text-foreground">Teachers</strong> sign in with their university email to mark attendance for the courses assigned to them.
              </p>
              <p className="mt-3 text-muted-foreground">
                <strong className="text-foreground">Administrators</strong> manage faculties, teachers, courses and students, and review reports across the campus.
              </p>
              <p className="mt-3 text-muted-foreground">Classes run Saturday to Wednesday, 4:30 PM – 9:20 PM.</p>
              <Button asChild className="mt-6"><Link to="/auth">Go to sign in</Link></Button>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-border">
        <div className="mx-auto max-w-6xl px-4 py-6 text-sm text-muted-foreground">
          © East Africa University – Gardo Campus · Attendance Management System
        </div>
      </footer>
    </div>
  );
}
