import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { useCurrentRole } from "@/lib/queries";
import { toast } from "sonner";
import { ACADEMIC_CALENDAR, ACADEMIC_YEAR, eventStatus, formatRange } from "@/lib/academic-calendar";

export const Route = createFileRoute("/_authenticated/settings")({
  staticData: { sitemap: false },
  head: () => ({
    meta: [
      { title: "Settings — EAU" },
      { name: "description", content: "EAU attendance system settings." },
      { property: "og:title", content: "Settings — EAU" },
      { property: "og:description", content: "EAU attendance system settings." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SettingsPage,
});

const KEY = "eau-settings";
const DEFAULTS = {
  universityName: "East Africa University",
  campusName: "Gardo Campus",
  contactEmail: "",
  contactPhone: "",
  allowEditing: true,
  timeLimitHours: "24",
  preventDuplicates: true,
  threshold: "75",
  sessionTimeout: "60",
  notifications: true,
  absentAlerts: true,
  reminders: true,
  announcements: true,
  theme: "light" as "light" | "dark",
  language: "English",
  sidebarCollapsed: false,
};
type S = typeof DEFAULTS;

function loadSettings(): S {
  try {
    return { ...DEFAULTS, ...JSON.parse(localStorage.getItem(KEY) ?? "{}"), threshold: localStorage.getItem("eau-absence-threshold") ?? "75" };
  } catch {
    return DEFAULTS;
  }
}

function Section({ title, desc, children }: { title: string; desc?: string; children: ReactNode }) {
  return (
    <Card className="border-border/60 rounded-2xl" style={{ boxShadow: "var(--shadow-card)" }}>
      <CardContent className="p-5 space-y-4">
        <div>
          <h3 className="font-semibold text-lg">{title}</h3>
          {desc && <p className="text-sm text-muted-foreground">{desc}</p>}
        </div>
        {children}
      </CardContent>
    </Card>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return <div className="space-y-1.5"><Label>{label}</Label>{children}</div>;
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex items-center justify-between gap-3 py-1">
      <span className="text-sm">{label}</span>
      <Switch checked={checked} onCheckedChange={onChange} />
    </label>
  );
}

function SettingsPage() {
  const [s, setS] = useState<S>(DEFAULTS);
  const { data: me } = useCurrentRole();
  const isAdmin = me?.role === "admin";
  useEffect(() => setS(loadSettings()), []);
  useEffect(() => {
    document.documentElement.classList.toggle("dark", s.theme === "dark");
  }, [s.theme]);
  const set = <K extends keyof S>(k: K, v: S[K]) => setS((p) => ({ ...p, [k]: v }));

  function save() {
    const t = Number(s.threshold);
    if (!(t >= 1 && t <= 100)) return toast.error("Threshold must be between 1 and 100.");
    localStorage.setItem(KEY, JSON.stringify(s));
    localStorage.setItem("eau-absence-threshold", String(t));
    toast.success("Settings saved.");
  }

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold">Settings</h1>
          <p className="text-muted-foreground mt-1">General configuration of the attendance system.</p>
        </div>
        <Button onClick={save}>Save Changes</Button>
      </div>

      <Tabs defaultValue="general">
        <TabsList className="flex flex-wrap h-auto">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="academic">Academic</TabsTrigger>
          <TabsTrigger value="attendance">Attendance</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
          <TabsTrigger value="backup">Database & Backup</TabsTrigger>
          <TabsTrigger value="activity">Activity Log</TabsTrigger>
          <TabsTrigger value="about">About</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="mt-4">
          <Section title="General Settings">
            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="University Name"><Input value={s.universityName} onChange={(e) => set("universityName", e.target.value)} /></Field>
              <Field label="Campus Name"><Input value={s.campusName} onChange={(e) => set("campusName", e.target.value)} /></Field>
              <Field label="Contact Email"><Input type="email" value={s.contactEmail} onChange={(e) => set("contactEmail", e.target.value)} /></Field>
              <Field label="Contact Phone"><Input value={s.contactPhone} onChange={(e) => set("contactPhone", e.target.value)} /></Field>
            </div>
            <div className="flex items-center gap-3">
              <img src="/favicon.png" alt="University logo" width={48} height={48} className="h-12 w-12 object-contain" />
              <span className="text-sm text-muted-foreground">University logo (current)</span>
            </div>
          </Section>
        </TabsContent>

        <TabsContent value="academic" className="mt-4 space-y-4"><AcademicCalendar /><AcademicSettings isAdmin={isAdmin} /></TabsContent>

        <TabsContent value="attendance" className="mt-4">
          <Section title="Attendance Configuration">
            <p className="text-sm">Statuses: <b>Present</b>, <b>Absent</b>, <b>Late</b>, <b>Excused</b></p>
            <Toggle label="Allow attendance editing" checked={s.allowEditing} onChange={(v) => set("allowEditing", v)} />
            <Toggle label="Prevent duplicate attendance (one record per student, course and day)" checked={s.preventDuplicates} onChange={(v) => set("preventDuplicates", v)} />
            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="Attendance time limit (hours to edit)"><Input type="number" min={1} value={s.timeLimitHours} onChange={(e) => set("timeLimitHours", e.target.value)} /></Field>
              <Field label="High-absence threshold (%)"><Input type="number" min={1} max={100} value={s.threshold} onChange={(e) => set("threshold", e.target.value)} /></Field>
            </div>
            <p className="text-sm text-muted-foreground">Percentage = Present days ÷ total marked days × 100. Class schedule: Saturday – Wednesday, 4:30 PM – 9:20 PM.</p>
          </Section>
        </TabsContent>

        <TabsContent value="security" className="mt-4 space-y-4">
          <ChangePassword />
          <Section title="Session & Permissions">
            <Field label="Session timeout (minutes)"><Input type="number" min={5} value={s.sessionTimeout} onChange={(e) => set("sessionTimeout", e.target.value)} className="w-40" /></Field>
            <ul className="text-sm space-y-1 list-disc pl-5">
              <li><b>Admin:</b> manage departments, teachers, courses, students, semesters and all attendance.</li>
              <li><b>Teacher:</b> mark and edit attendance only for assigned courses.</li>
              <li><b>Student:</b> view own attendance history (read only).</li>
            </ul>
            <p className="text-sm text-muted-foreground">Login security: passwords are encrypted and every sign-in is verified.</p>
          </Section>
        </TabsContent>

        <TabsContent value="notifications" className="mt-4">
          <Section title="Notification Settings">
            <Toggle label="Enable notifications" checked={s.notifications} onChange={(v) => set("notifications", v)} />
            <Toggle label="Absent student alerts" checked={s.absentAlerts} onChange={(v) => set("absentAlerts", v)} />
            <Toggle label="Attendance reminders" checked={s.reminders} onChange={(v) => set("reminders", v)} />
            <Toggle label="System announcements" checked={s.announcements} onChange={(v) => set("announcements", v)} />
          </Section>
        </TabsContent>

        <TabsContent value="appearance" className="mt-4">
          <Section title="Appearance Settings">
            <div className="flex gap-2">
              {(["light", "dark"] as const).map((t) => (
                <Button key={t} variant={s.theme === t ? "default" : "outline"} onClick={() => set("theme", t)} className="capitalize">{t}</Button>
              ))}
            </div>
            <p className="text-sm">Primary color: <b>Navy Blue</b> · Secondary color: <b>White</b> · Language: <b>English</b></p>
            <Toggle label="Start with sidebar collapsed" checked={s.sidebarCollapsed} onChange={(v) => set("sidebarCollapsed", v)} />
          </Section>
        </TabsContent>

        <TabsContent value="backup" className="mt-4"><BackupSection /></TabsContent>
        <TabsContent value="activity" className="mt-4"><ActivityLog /></TabsContent>

        <TabsContent value="about" className="mt-4">
          <Section title="About System">
            <dl className="grid grid-cols-[auto_1fr] gap-x-6 gap-y-2 text-sm">
              <dt className="text-muted-foreground">System Name</dt><dd>EAU Attendance System</dd>
              <dt className="text-muted-foreground">University</dt><dd>East Africa University</dd>
              <dt className="text-muted-foreground">Campus</dt><dd>Gardo Campus</dd>
              <dt className="text-muted-foreground">Version</dt><dd>1.0</dd>
              <dt className="text-muted-foreground">Developed for</dt><dd>East Africa University – Gardo Campus</dd>
              <dt className="text-muted-foreground">Support</dt><dd>Eng. Khadra Liban Jama Rabax · 6943912 (see Help & Support)</dd>
            </dl>
          </Section>
        </TabsContent>
      </Tabs>
    </div>
  );
}

type Sem = { id: string; name: string; academic_year: string | null; start_date: string | null; end_date: string | null; status: string };

function AcademicSettings({ isAdmin }: { isAdmin: boolean }) {
  const [rows, setRows] = useState<Sem[]>([]);
  const [form, setForm] = useState({ name: "", academic_year: "2026-2027", start_date: "", end_date: "" });
  async function load() {
    const { data } = await supabase.from("semesters").select("*").order("created_at", { ascending: false });
    setRows((data as Sem[]) ?? []);
  }
  useEffect(() => { load(); }, []);

  async function add() {
    if (!form.name) return toast.error("Enter a semester name.");
    const { error } = await supabase.from("semesters").insert({ ...form, start_date: form.start_date || null, end_date: form.end_date || null, status: "inactive" });
    if (error) return toast.error(error.message);
    toast.success("Semester added.");
    setForm({ ...form, name: "", start_date: "", end_date: "" });
    load();
  }
  async function activate(id: string) {
    // Old semesters are kept (status "closed"); their attendance is never deleted.
    const { error: e1 } = await supabase.from("semesters").update({ status: "closed" }).eq("status", "active");
    const { error } = await supabase.from("semesters").update({ status: "active" }).eq("id", id);
    if (e1 || error) return toast.error((e1 ?? error)!.message);
    toast.success("Active semester updated. Previous semesters and their attendance are kept.");
    load();
  }
  const active = rows.find((r) => r.status === "active");

  return (
    <Section title="Academic Settings" desc="When a new semester starts, earlier semesters stay saved and their attendance is never lost.">
      <p className="text-sm">Current semester: <b>{active ? `${active.name} (${active.academic_year ?? ""})` : "None set"}</b></p>
      {isAdmin && (
        <div className="grid sm:grid-cols-5 gap-3 items-end">
          <Field label="Semester"><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="First Term" /></Field>
          <Field label="Academic Year"><Input value={form.academic_year} onChange={(e) => setForm({ ...form, academic_year: e.target.value })} /></Field>
          <Field label="Start Date"><Input type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} /></Field>
          <Field label="End Date"><Input type="date" value={form.end_date} onChange={(e) => setForm({ ...form, end_date: e.target.value })} /></Field>
          <Button onClick={add}>Add</Button>
        </div>
      )}
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="text-left text-muted-foreground border-b"><th className="py-2">Semester</th><th>Year</th><th>Start</th><th>End</th><th>Status</th><th /></tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-b last:border-0">
                <td className="py-2">{r.name}</td><td>{r.academic_year}</td><td>{r.start_date ?? "—"}</td><td>{r.end_date ?? "—"}</td>
                <td className="capitalize">{r.status}</td>
                <td className="text-right">{isAdmin && r.status !== "active" && <Button size="sm" variant="outline" onClick={() => activate(r.id)}>Set Active</Button>}</td>
              </tr>
            ))}
            {!rows.length && <tr><td colSpan={6} className="py-4 text-muted-foreground">No semesters yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </Section>
  );
}

function ChangePassword() {
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  async function change() {
    if (pw.length < 6) return toast.error("Password must be at least 6 characters.");
    if (pw !== pw2) return toast.error("Passwords do not match.");
    const { error } = await supabase.auth.updateUser({ password: pw });
    if (error) return toast.error(error.message);
    setPw(""); setPw2("");
    toast.success("Password changed.");
  }
  return (
    <Section title="Change Password">
      <div className="grid sm:grid-cols-3 gap-3 items-end">
        <Field label="New password"><Input type="password" value={pw} onChange={(e) => setPw(e.target.value)} /></Field>
        <Field label="Confirm password"><Input type="password" value={pw2} onChange={(e) => setPw2(e.target.value)} /></Field>
        <Button onClick={change}>Change Password</Button>
      </div>
    </Section>
  );
}

function BackupSection() {
  const [busy, setBusy] = useState(false);
  async function exportData() {
    setBusy(true);
    const all: any[] = [];
    for (let from = 0; ; from += 1000) {
      const { data, error } = await supabase
        .from("attendance")
        .select("date,status,remarks,students(student_no,full_name),courses(name,code)")
        .order("date")
        .range(from, from + 999);
      if (error) { setBusy(false); return toast.error(error.message); }
      all.push(...(data ?? []));
      if (!data || data.length < 1000) break;
    }
    const esc = (v: unknown) => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const csv = ["Date,Student No,Student,Course Code,Course,Status,Remarks",
      ...all.map((r) => [r.date, r.students?.student_no, r.students?.full_name, r.courses?.code, r.courses?.name, r.status, r.remarks].map(esc).join(","))].join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    a.download = `eau-attendance-export-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    setBusy(false);
    toast.success(`Exported ${all.length} attendance records.`);
  }
  return (
    <Section title="Database & Backup" desc="Your data is protected by real, automatic backups.">
      <ul className="text-sm space-y-1 list-disc pl-5">
        <li>The database is backed up automatically <b>every day</b>; about the last 14 days are kept.</li>
        <li>Last backup and restore (admin only): open your project's backend → Database → Backups. A restore replaces all data changed after that backup.</li>
        <li>A full copy of the database can be exported from the backend's Database settings.</li>
      </ul>
      <Button onClick={exportData} disabled={busy}>{busy ? "Exporting…" : "Export attendance data (CSV)"}</Button>
    </Section>
  );
}

type Log = { id: string; action: string; old_status: string | null; new_status: string | null; date: string; changed_at: string; changed_by: string | null; student_id: string; course_id: string };

function ActivityLog() {
  const [rows, setRows] = useState<(Log & { student?: string; course?: string })[]>([]);
  const [lastLogin, setLastLogin] = useState<string | null>(null);
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setLastLogin(data.user?.last_sign_in_at ?? null));
    (async () => {
      const { data } = await supabase.from("attendance_log").select("*").order("changed_at", { ascending: false }).limit(100);
      const logs = (data as Log[]) ?? [];
      const sIds = [...new Set(logs.map((l) => l.student_id))];
      const cIds = [...new Set(logs.map((l) => l.course_id))];
      const [{ data: st }, { data: co }] = await Promise.all([
        sIds.length ? supabase.from("students").select("id,full_name").in("id", sIds) : Promise.resolve({ data: [] as any[] }),
        cIds.length ? supabase.from("courses").select("id,name").in("id", cIds) : Promise.resolve({ data: [] as any[] }),
      ]);
      const sm = new Map((st ?? []).map((x: any) => [x.id, x.full_name]));
      const cm = new Map((co ?? []).map((x: any) => [x.id, x.name]));
      setRows(logs.map((l) => ({ ...l, student: sm.get(l.student_id), course: cm.get(l.course_id) })));
    })();
  }, []);
  return (
    <Section title="System Activity Log" desc="Who created or changed attendance records, and when (latest 100).">
      <p className="text-sm">Your last sign-in: <b>{lastLogin ? new Date(lastLogin).toLocaleString() : "—"}</b></p>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="text-left text-muted-foreground border-b"><th className="py-2">Date & Time</th><th>Action</th><th>Student</th><th>Course</th><th>Class day</th><th>Change</th><th>User</th></tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-b last:border-0">
                <td className="py-2 whitespace-nowrap">{new Date(r.changed_at).toLocaleString()}</td>
                <td className="capitalize">{r.action}</td>
                <td>{r.student ?? "—"}</td>
                <td>{r.course ?? "—"}</td>
                <td>{r.date}</td>
                <td className="capitalize">{r.old_status ?? "—"} → {r.new_status ?? "—"}</td>
                <td className="font-mono text-xs">{r.changed_by ? r.changed_by.slice(0, 8) : "system"}</td>
              </tr>
            ))}
            {!rows.length && <tr><td colSpan={7} className="py-4 text-muted-foreground">No activity yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </Section>
  );
}

function AcademicCalendar() {
  return (
    <Section title={`EAU Qardho Academic Calendar ${ACADEMIC_YEAR}`} desc="Official dates for the academic year. The current activity is highlighted.">
      <div className="grid md:grid-cols-2 gap-4">
        {ACADEMIC_CALENDAR.map((s) => (
          <div key={s.semester} className="rounded-xl border border-border overflow-hidden">
            <div className="bg-primary text-primary-foreground px-4 py-2 font-semibold">{s.semester}</div>
            <table className="w-full text-sm">
              <tbody>
                {s.events.map((e, i) => {
                  const st = eventStatus(e);
                  return (
                    <tr key={i} className={`border-b last:border-0 ${st === "now" ? "bg-accent font-semibold" : st === "done" ? "text-muted-foreground" : ""}`}>
                      <td className="px-3 py-2 whitespace-nowrap">{formatRange(e)}</td>
                      <td className="px-3 py-2">{e.activity}{st === "now" && " (now)"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ))}
      </div>
    </Section>
  );
}
