import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/department/$deptId")({
  staticData: { sitemap: false },
  head: () => ({ meta: [
    {"title": "Faculty Details \u2014 EAU Gardo"},
    {"name": "description", "content": "View faculty students, semester totals and assigned courses at EAU Gardo."},
    {"property": "og:title", "content": "Faculty Details \u2014 EAU Gardo"},
    {"property": "og:description", "content": "View faculty students, semester totals and assigned courses at EAU Gardo."},
    {"property": "og:type", "content": "website"},
    {"name": "twitter:card", "content": "summary"},
  ] }),
  component: DepartmentDetail,
});

const SEMESTERS = [1, 2, 3, 4, 5, 6, 7, 8];

function DepartmentDetail() {
  const { deptId } = Route.useParams();
  const [dept, setDept] = useState<any>(null);
  const [courses, setCourses] = useState<any[]>([]);
  const [counts, setCounts] = useState<Record<number, number>>({});
  const [total, setTotal] = useState(0);

  useEffect(() => {
    (async () => {
      const [{ data: d }, { data: c }, { count }] = await Promise.all([
        supabase.from("departments").select("*").eq("id", deptId).maybeSingle(),
        supabase.from("courses").select("*, teachers(full_name)").eq("department_id", deptId).order("semester"),
        supabase.from("students").select("id", { count: "exact", head: true }).eq("department_id", deptId),
      ]);
      setDept(d);
      setCourses(c ?? []);
      setTotal(count ?? 0);
      const per = await Promise.all(
        SEMESTERS.map(async (s) => {
          const { count: n } = await supabase
            .from("students")
            .select("id", { count: "exact", head: true })
            .eq("department_id", deptId)
            .eq("semester", s);
          return [s, n ?? 0] as const;
        }),
      );
      setCounts(Object.fromEntries(per));
    })();
  }, [deptId]);

  if (!dept) return <p className="text-muted-foreground">Loading department…</p>;

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <Link to="/departments" className="text-sm text-primary hover:underline">← All departments</Link>
          <h1 className="text-4xl font-bold mt-1">{dept.name}</h1>
          <p className="text-muted-foreground mt-1">
            Code {dept.code} · {total} students · {courses.length} courses · 8 semesters
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {SEMESTERS.map((s) => (
          <Card key={s} className="border-border/60 rounded-2xl">
            <CardContent className="p-4">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Semester {s}</div>
              <div className="text-2xl font-bold mt-1">{counts[s] ?? 0}</div>
              <div className="text-xs text-muted-foreground">students</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {SEMESTERS.map((s) => {
          const list = courses.filter((c) => c.semester === s);
          return (
            <Card key={s} className="border-border/60 rounded-2xl">
              <CardContent className="p-5">
                <h3 className="font-semibold mb-3">Semester {s} courses</h3>
                <ul className="space-y-2">
                  {list.map((c) => (
                    <li key={c.id} className="flex items-center justify-between gap-3 text-sm border-b border-border/50 pb-2 last:border-0">
                       <span className="font-medium">{c.name}{c.credit_hours != null && <span className="block text-xs text-muted-foreground">{c.credit_hours} credit hours</span>}</span>
                      <span className="text-muted-foreground text-xs">{c.teachers?.full_name ?? "Unassigned"}</span>
                    </li>
                  ))}
                  {list.length === 0 && <li className="text-sm text-muted-foreground">No courses yet.</li>}
                </ul>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}