import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { askAttendanceAssistant } from "@/lib/assistant.functions";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Bot } from "lucide-react";

export const Route = createFileRoute("/_authenticated/assistant")({
  staticData: { sitemap: false },
  head: () => ({
    meta: [
      { title: "AI Attendance Assistant — EAU" },
      { name: "description", content: "Ask questions about attendance and get answers from real EAU attendance records." },
      { property: "og:title", content: "AI Attendance Assistant — EAU" },
      { property: "og:description", content: "AI answers grounded in real attendance data." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AssistantPage,
});

const SUGGESTIONS = [
  "Which students have the highest absence rate?",
  "Show me the daily attendance trend for the last month",
  "Which course has the lowest attendance?",
  "How is the attendance of a student named…",
];

function AssistantPage() {
  const [question, setQuestion] = useState("");
  const [history, setHistory] = useState<{ q: string; a: string }[]>([]);

  const ask = useMutation({
    mutationFn: (q: string) => askAttendanceAssistant({ data: { question: q } }),
    onSuccess: (res, q) => setHistory((h) => [{ q, a: res.answer }, ...h]),
  });

  function submit(q: string) {
    const trimmed = q.trim();
    if (!trimmed || ask.isPending) return;
    setQuestion("");
    ask.mutate(trimmed);
  }

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2"><Bot className="h-7 w-7 text-primary" /> AI Attendance Assistant</h1>
        <p className="text-muted-foreground mt-1">
          Ask about attendance — every answer is computed from the real database. Available to administrators and lecturers.
        </p>
      </div>

      <Card className="border-border/60 rounded-2xl" style={{ boxShadow: "var(--shadow-card)" }}>
        <CardContent className="p-5 space-y-3">
          <Textarea
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(question); } }}
            placeholder="e.g. Which students have the worst attendance this semester?"
            rows={3}
          />
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div className="flex flex-wrap gap-2">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => submit(s)}
                  className="text-xs border border-border rounded-full px-3 py-1.5 text-muted-foreground hover:bg-accent transition"
                >
                  {s}
                </button>
              ))}
            </div>
            <Button onClick={() => submit(question)} disabled={!question.trim() || ask.isPending}>
              {ask.isPending ? "Thinking…" : "Ask"}
            </Button>
          </div>
          {ask.isError && (
            <p className="text-sm text-destructive">{ask.error instanceof Error ? ask.error.message : "Something went wrong."}</p>
          )}
        </CardContent>
      </Card>

      {ask.isPending && (
        <Card className="border-border/60 rounded-2xl" style={{ boxShadow: "var(--shadow-card)" }}>
          <CardContent className="p-5 text-sm text-muted-foreground">Querying attendance records and composing the answer…</CardContent>
        </Card>
      )}

      {history.map((h, i) => (
        <Card key={i} className="border-border/60 rounded-2xl" style={{ boxShadow: "var(--shadow-card)" }}>
          <CardContent className="p-5 space-y-3">
            <div className="text-sm font-semibold text-primary">{h.q}</div>
            <div className="text-sm whitespace-pre-wrap leading-relaxed">{h.a}</div>
          </CardContent>
        </Card>
      ))}

      {!history.length && !ask.isPending && (
        <p className="text-sm text-muted-foreground text-center py-6">No questions yet — try one of the suggestions above.</p>
      )}
    </div>
  );
}
