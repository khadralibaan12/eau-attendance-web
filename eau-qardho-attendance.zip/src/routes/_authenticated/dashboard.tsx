import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useDashboardStats } from "@/lib/queries";
import { Card, CardContent } from "@/components/ui/card";
import { Building2, Users, BookOpen, GraduationCap, Calendar, Clock } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard")({
  staticData: { sitemap: false },
  head: () => ({ meta: [
    {"title": "Attendance Overview \u2014 EAU Gardo"},
    {"name": "description", "content": "View real student, teacher, faculty and course totals at EAU Gardo."},
    {"property": "og:title", "content": "Attendance Overview \u2014 EAU Gardo"},
    {"property": "og:description", "content": "View real student, teacher, faculty and course totals at EAU Gardo."},
    {"property": "og:type", "content": "website"},
    {"name": "twitter:card", "content": "summary"},
  ] }),
  component: Dashboard,
});

function StatCard({ label, value, Icon, to }: any) {
  const navigate = useNavigate();
  return (
    <Card
      onClick={() => to && navigate({ to })}
      className={`border-border/60 bg-card ${to ? "cursor-pointer hover:shadow-md transition-shadow" : ""}`}
      style={{ boxShadow: "var(--shadow-card)" }}
    >
      <CardContent className="p-5 flex items-start justify-between">
        <div>
          <div className="text-xs font-semibold tracking-wider text-muted-foreground uppercase">{label}</div>
          <div className="text-4xl font-bold mt-2 text-foreground">{value ?? "—"}</div>
        </div>
        <div className="h-11 w-11 rounded-xl bg-accent grid place-items-center text-primary shrink-0">
          <Icon className="h-5 w-5" />
        </div>
      </CardContent>
    </Card>
  );
}

function Dashboard() {
  const { data: stats = {} as any } = useDashboardStats();

  const days = ["Saturday", "Sunday", "Monday", "Tuesday", "Wednesday"];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-bold text-foreground">Overview</h1>
        <p className="text-muted-foreground mt-1">Overview of the attendance system for East Africa University – Gardo Campus (EAU Gardo).</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Departments" value={stats.departments} Icon={Building2} to="/departments" />
        <StatCard label="Teachers" value={stats.teachers} Icon={Users} to="/teachers" />
        <StatCard label="Courses" value={stats.courses} Icon={BookOpen} to="/courses" />
        <StatCard label="Students" value={stats.students} Icon={GraduationCap} to="/students" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="border-border/60 bg-card" style={{ boxShadow: "var(--shadow-card)" }}>
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <Calendar className="h-5 w-5 text-primary" />
              <h3 className="font-semibold text-lg">Class Days</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {days.map((d) => (
                <span key={d} className="px-4 py-1.5 rounded-full bg-accent text-accent-foreground text-sm font-medium">{d}</span>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/60 bg-card" style={{ boxShadow: "var(--shadow-card)" }}>
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <Clock className="h-5 w-5 text-primary" />
              <h3 className="font-semibold text-lg">Class Time</h3>
            </div>
            <div className="text-3xl font-bold text-foreground">4:30 PM <span className="text-primary">→</span> 9:20 PM</div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}