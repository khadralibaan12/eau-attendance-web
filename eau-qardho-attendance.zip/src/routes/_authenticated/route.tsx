import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { useEffect, useState } from "react";
import { Clock } from "lucide-react";

export const Route = createFileRoute("/_authenticated")({
  staticData: { sitemap: "exclude-subtree" },
  ssr: false,
  beforeLoad: async () => {
    // Read the locally persisted session instead of a network round-trip to
    // Auth: getUser() added seconds before the first paint (poor LCP).
    const { data, error } = await supabase.auth.getSession();
    if (error || !data.session?.user) throw redirect({ to: "/auth" });
    return { user: data.session.user };
  },
  component: AuthedLayout,
});

// Isolated so the 1s tick re-renders only the clock, not the whole page.
function HeaderClock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  const time = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true });
  const date = now.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" });
  return (
    <>
      <span className="font-mono font-semibold text-primary tracking-wider">{time}</span>
      <span className="text-muted-foreground">·</span>
      <span className="text-foreground/80">{date}</span>
    </>
  );
}

function AuthedLayout() {
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-background">
        <AppSidebar />
        <div className="flex-1 flex flex-col min-w-0">
          <header className="h-16 flex items-center justify-between bg-background px-6">
            <div className="flex items-center gap-3 min-w-0">
              <SidebarTrigger className="text-primary" />
              <h2 className="text-lg sm:text-xl font-semibold text-foreground truncate">East Africa University – Gardo Campus</h2>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <Clock className="h-4 w-4 text-primary" />
              <HeaderClock />
              <span className="text-muted-foreground hidden sm:inline">·</span>
              <span className="hidden sm:inline font-medium text-foreground">Admin</span>
            </div>
          </header>
          <main className="flex-1 p-6 overflow-auto">
            <Outlet />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}