import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useDepartments } from "@/lib/queries";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import * as XLSX from "xlsx";
import { classReportStats, includeMonthlyRoster, monthRange, type ClassAttendance, type MonthlyStudent, type StudentReport } from "@/lib/monthly-report";

export const Route = createFileRoute("/_authenticated/reports")({
  staticData: { sitemap: false },
  head: () => ({
    meta: [
      { title: "Attendance Reports & Analysis — EAU" },
      { name: "description", content: "Daily, weekly, monthly and semester attendance reports with charts, absence analysis and Excel/PDF export." },
      { property: "og:title", content: "Attendance Reports & Analysis — EAU" },
      { property: "og:description", content: "Attendance reports, trends and high-absence analysis for East Africa University." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ReportsPage,
});

type View = "daily" | "weekly" | "monthly" | "semester";

function threshold(): number {
  const v = Number(localStorage.getItem("eau-absence-threshold"));
  return v >= 1 && v <= 100 ? v : 75;
}

function weekKey(d: string) {
  const date = new Date(`${d}T00:00:00`);
  const day = (date.getDay() + 6) % 7; // Monday = 0
  const monday = new Date(date);
  monday.setDate(date.getDate() - day);
  return monday.toISOString().slice(0, 10);
}

function ReportsPage() {
  const { data: departments = [] } = useDepartments();
  const [dept, setDept] = useState("");
  const [sem, setSem] = useState("");
  const [course, setCourse] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [view, setView] = useState<View>("monthly");
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7));
  const [classCode, setClassCode] = useState("");
  const activeClass = view === "monthly" ? classCode : "";
  const range = view === "monthly" ? monthRange(month) : { from, to };
  const reportLabel = view === "monthly" ? `Monthly Attendance — ${month}` : `Attendance Report — ${view}`;

  const filters = {
    p_dept: dept || undefined,
    p_sem: sem ? Number(sem) : undefined,
    p_course: course || undefined,
    p_from: range.from || undefined,
    p_to: range.to || undefined,
  };

  const { data: courses = [] } = useQuery({
    queryKey: ["report-courses", dept, sem],
    queryFn: async () => {
      let q = supabase.from("courses").select("id, name, credit_hours, teachers(full_name)").order("name");
      if (dept) q = q.eq("department_id", dept);
      if (sem) q = q.eq("semester", Number(sem));
      const { data } = await q.limit(200);
      return data ?? [];
    },
  });

  const { data: classes = [], error: classesError } = useQuery({
    queryKey: ["monthly-report-classes", dept, sem],
    enabled: view === "monthly",
    queryFn: async () => {
      const codes = new Set<string>();
      for (let offset = 0; ; offset += 500) {
        let query = supabase.from("students").select("class_code").not("class_code", "is", null);
        if (dept) query = query.eq("department_id", dept);
        if (sem) query = query.eq("semester", Number(sem));
        const { data, error } = await query.order("id").range(offset, offset + 499);
        if (error) throw error;
        for (const student of data ?? []) if (student.class_code) codes.add(student.class_code);
        if ((data ?? []).length < 500) return [...codes].sort();
      }
    },
  });

  const { data: recordedStats = [], isFetching: loadingStudents, error: statsError } = useQuery({
    queryKey: ["report-students", filters],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("attendance_student_stats", filters);
      if (error) throw error;
      return (data ?? []) as StudentReport[];
    },
  });

  const { data: monthlyStudents = [], isFetching: loadingRoster, error: rosterError } = useQuery({
    queryKey: ["monthly-report-roster", dept, sem, course, activeClass],
    enabled: view === "monthly",
    queryFn: async () => {
      const students: MonthlyStudent[] = [];
      for (let offset = 0; ; offset += 500) {
        let query = supabase.from("students").select(course
          ? "id, full_name, student_no, department_id, semester, class_code, departments(name), enrollments!inner(course_id)"
          : "id, full_name, student_no, department_id, semester, class_code, departments(name)");
        if (dept) query = query.eq("department_id", dept);
        if (sem) query = query.eq("semester", Number(sem));
        if (course) query = query.eq("enrollments.course_id", course);
        if (activeClass) query = query.eq("class_code", activeClass);
        const { data, error } = await query.order("full_name").order("id").range(offset, offset + 499);
        if (error) throw error;
        const page = (data ?? []) as unknown as MonthlyStudent[];
        students.push(...page);
        if (page.length < 500) return students;
      }
    },
  });
  const studentStats = useMemo(() => view === "monthly"
    ? includeMonthlyRoster(monthlyStudents, recordedStats, activeClass, sem) : recordedStats,
  [view, monthlyStudents, recordedStats, activeClass, sem]);

  const { data: classRecords = [], isFetching: loadingClass, error: classError } = useQuery({
    queryKey: ["monthly-class-attendance", activeClass, filters],
    enabled: !!activeClass,
    queryFn: async () => {
      const records: ClassAttendance[] = [];
      for (let offset = 0; ; offset += 500) {
        let query = supabase.from("attendance").select("date, status, course_id, students!inner(class_code, department_id, semester), courses(name, teachers(full_name))")
          .eq("students.class_code", activeClass).gte("date", range.from).lte("date", range.to);
        if (dept) query = query.eq("students.department_id", dept);
        if (sem) query = query.eq("students.semester", Number(sem));
        if (course) query = query.eq("course_id", course);
        const { data, error } = await query.order("id").range(offset, offset + 499);
        if (error) throw error;
        const page = (data ?? []) as unknown as ClassAttendance[];
        records.push(...page);
        if (page.length < 500) return records;
      }
    },
  });
  const classStats = useMemo(() => classReportStats(classRecords), [classRecords]);
  const reportLoading = loadingStudents || (view === "monthly" && loadingRoster) || (!!activeClass && loadingClass);
  const reportError = statsError || (view === "monthly" && (rosterError || classesError)) || (!!activeClass && classError);

  const { data: allDaily = [] } = useQuery({
    queryKey: ["report-daily", filters],
    queryFn: async () => {
      const { data } = await supabase.rpc("attendance_daily_stats", filters);
      return (data ?? []) as any[];
    },
  });

  const { data: allCourseStats = [] } = useQuery({
    queryKey: ["report-course-stats", dept, sem, range.from, range.to],
    queryFn: async () => {
      const { data } = await supabase.rpc("attendance_course_stats", {
        p_dept: dept || undefined, p_sem: sem ? Number(sem) : undefined, p_from: range.from || undefined, p_to: range.to || undefined,
      });
      return (data ?? []) as any[];
    },
  });

  const daily = activeClass ? classStats.daily : allDaily;
  const courseStats = activeClass ? classStats.courses : allCourseStats;

  const selectedCourse = (courses as any[]).find((c) => c.id === course);
  const selectedCourseName = selectedCourse?.name ?? "";
  // Each period = course credit hours ÷ 4 periods.
  const hoursPerPeriod = selectedCourse?.credit_hours != null ? Number(selectedCourse.credit_hours) / 4 : null;
  const fmtH = (n: number) => (Math.round(n * 100) / 100).toString();

  const limit = threshold();

  const flagged = useMemo(
    () => studentStats.filter((s: any) => Number(s.total) > 0 && Number(s.pct) < limit),
    [studentStats, limit],
  );

  const chartData = useMemo(() => {
    if (view === "daily") {
      return daily.map((d: any) => ({ label: String(d.day).slice(5), present: Number(d.present), absent: Number(d.absent), pct: Number(d.pct) }));
    }
    const map = new Map<string, { label: string; present: number; absent: number }>();
    daily.forEach((d: any) => {
      const key = view === "weekly" ? `Week of ${weekKey(String(d.day)).slice(5)}` : String(d.day).slice(0, 7);
      const row = map.get(key) ?? { label: key, present: 0, absent: 0 };
      row.present += Number(d.present);
      row.absent += Number(d.absent);
      map.set(key, row);
    });
    return [...map.values()].map((r) => ({
      ...r,
      pct: r.present + r.absent ? Math.round((r.present / (r.present + r.absent)) * 1000) / 10 : 0,
    }));
  }, [daily, view]);

  const totals = useMemo(() => {
    const present = studentStats.reduce((a: number, s: any) => a + Number(s.present), 0);
    const absent = studentStats.reduce((a: number, s: any) => a + Number(s.absent), 0);
    const total = present + absent;
    return { present, absent, total, pct: total ? Math.round((present / total) * 1000) / 10 : 0 };
  }, [studentStats]);

  const best = useMemo(() => [...courseStats].filter((c: any) => !course || c.course_id === course).sort((a, b) => Number(b.pct) - Number(a.pct)), [courseStats, course]);

  function exportExcel() {
    const rows = studentStats.map((s: any, i: number) => ({
      "#": i + 1,
      Student: s.student_name,
      "Student No": s.student_no,
      Department: s.department_name,
      Semester: s.semester,
      Class: activeClass || "All classes",
      Course: selectedCourseName || "All courses",
      From: range.from || "All time",
      To: range.to || "Today",
      Present: Number(s.present),
      Absent: Number(s.absent),
      Total: Number(s.total),
      "Hours attended": hoursPerPeriod == null ? "" : Number(s.present) * hoursPerPeriod,
      "Attendance %": s.total ? Number(s.pct) : "",
      Flagged: Number(s.total) > 0 && Number(s.pct) < limit ? "YES" : "",
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Attendance");
    XLSX.writeFile(wb, `eau-attendance-${view}-${view === "monthly" ? month : new Date().toISOString().slice(0, 10)}.xlsx`);
  }

  function exportPdf() {
    const w = window.open("", "_blank");
    if (!w) return;
    const escape = (value: unknown) => String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char] ?? char);
    const rows = studentStats
      .map(
        (s: any, i: number) =>
          `<tr><td>${i + 1}</td><td>${escape(s.student_name)}</td><td>${escape(s.student_no)}</td><td>${escape(s.department_name)}</td><td>S${s.semester}</td><td>${s.present}</td><td>${s.absent}</td><td>${s.total ? `${s.pct}%` : "—"}</td></tr>`,
      )
      .join("");
    w.document.write(`<!doctype html><html><head><title>EAU ${escape(reportLabel)}</title><style>
      body{font-family:Arial,sans-serif;padding:24px;color:#0f172a}
      h1{font-size:20px;margin:0 0 4px}.sub{color:#64748b;font-size:12px;margin-bottom:16px}
      table{width:100%;border-collapse:collapse;font-size:12px}
      th,td{border:1px solid #e2e8f0;padding:6px 8px;text-align:left}
      th{background:#dbeafe;color:#1e3a8a}
    </style></head><body>
      <h1>EAU ${escape(reportLabel)}</h1>
      <div class="sub">${escape(range.from || "All time")} → ${escape(range.to || "today")} · ${escape(activeClass || "All classes")} · ${escape(sem ? `Semester ${sem}` : "All semesters")} · ${escape(selectedCourseName || "All courses")} · Present ${totals.present} · Absent ${totals.absent} · ${totals.pct}% · Flagged below ${limit}%: ${flagged.length}</div>
      <table><thead><tr><th>#</th><th>Student</th><th>ID</th><th>Department</th><th>Sem</th><th>Present</th><th>Absent</th><th>%</th></tr></thead><tbody>${rows}</tbody></table>
      <script>window.onload=()=>window.print()</script></body></html>`);
    w.document.close();
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold">Attendance Reports & Analysis</h1>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={exportExcel} disabled={reportLoading || !!reportError || !studentStats.length}>Download Excel</Button>
          <Button onClick={exportPdf} disabled={reportLoading || !!reportError || !studentStats.length}>Export PDF</Button>
        </div>
      </div>

      <Card className="border-border/60 rounded-2xl" style={{ boxShadow: "var(--shadow-card)" }}>
        <CardContent className="p-5 space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            <div>
              <div className="text-xs font-medium text-muted-foreground mb-1.5">Department</div>
              <Select value={dept} onValueChange={(v) => { setDept(v === "all" ? "" : v); setCourse(""); setClassCode(""); }}>
                <SelectTrigger><SelectValue placeholder="All" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All departments</SelectItem>
                  {departments.map((d: any) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <div className="text-xs font-medium text-muted-foreground mb-1.5">Semester</div>
              <Select value={sem || "all"} onValueChange={(v) => { setSem(v === "all" ? "" : v); setCourse(""); setClassCode(""); }}>
                <SelectTrigger aria-label="Semester"><SelectValue placeholder="All" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All semesters</SelectItem>
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => <SelectItem key={s} value={String(s)}>Semester {s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            {view === "monthly" && <div>
              <div className="text-xs font-medium text-muted-foreground mb-1.5">Class</div>
              <Select value={classCode || "all"} onValueChange={(value) => setClassCode(value === "all" ? "" : value)}>
                <SelectTrigger aria-label="Class"><SelectValue placeholder="All classes" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All classes</SelectItem>
                  {classes.map((code) => <SelectItem key={code} value={code}>{code}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>}
            <div>
              <div className="text-xs font-medium text-muted-foreground mb-1.5">Course</div>
              <Select value={course} onValueChange={(v) => setCourse(v === "all" ? "" : v)}>
                <SelectTrigger><SelectValue placeholder="All" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All courses</SelectItem>
                  {courses.map((c: any) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            {view === "monthly" ? <div>
              <label htmlFor="report-month" className="block text-xs font-medium text-muted-foreground mb-1.5">Month</label>
              <Input id="report-month" type="month" value={month} onChange={(e) => { if (/^\d{4}-(0[1-9]|1[0-2])$/.test(e.target.value)) setMonth(e.target.value); }} />
            </div> : <><div>
              <div className="text-xs font-medium text-muted-foreground mb-1.5">From</div>
              <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
            </div>
            <div>
              <div className="text-xs font-medium text-muted-foreground mb-1.5">To</div>
              <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
            </div></>}
          </div>
          <div>
            <div className="text-xs font-medium text-muted-foreground mb-1.5">View</div>
            <Tabs value={view} onValueChange={(v) => setView(v as View)}>
              <TabsList className="grid grid-cols-4 w-full max-w-md">
                <TabsTrigger value="daily">Daily</TabsTrigger>
                <TabsTrigger value="weekly">Weekly</TabsTrigger>
                <TabsTrigger value="monthly">Monthly</TabsTrigger>
                <TabsTrigger value="semester">Semester</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Present", value: totals.present },
          { label: "Absent", value: totals.absent },
          { label: "Attendance %", value: `${totals.pct}%` },
          { label: `Below ${limit}% (flagged)`, value: flagged.length },
        ].map((s) => (
          <Card key={s.label} className="border-border/60 rounded-2xl" style={{ boxShadow: "var(--shadow-card)" }}>
            <CardContent className="p-5">
              <div className="text-sm text-muted-foreground">{s.label}</div>
              <div className="text-4xl font-bold mt-2">{s.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-border/60 rounded-2xl" style={{ boxShadow: "var(--shadow-card)" }}>
        <CardContent className="p-0">
          <div className="p-4 border-b flex items-center justify-between">
            <h3 className="font-semibold text-lg">{view === "monthly" ? `${reportLabel}${activeClass ? ` · ${activeClass}` : ""}${sem ? ` · Semester ${sem}` : ""}` : "Per-student totals"}</h3>
            <span className="text-sm text-muted-foreground">{reportLoading ? "Loading…" : `${studentStats.length} students`}</span>
          </div>
          {reportError && <p role="alert" className="p-4 text-destructive">Could not load attendance. Please try again.</p>}
          <Table>
            <TableHeader>
              <TableRow className="bg-accent/60">
                <TableHead>#</TableHead>
                <TableHead>Student</TableHead>
                <TableHead>ID</TableHead>
                <TableHead>Department</TableHead>
                <TableHead>Sem</TableHead>
                <TableHead>Course</TableHead>
                <TableHead className="text-right">Present</TableHead>
                <TableHead className="text-right">Absent</TableHead>
                <TableHead className="text-right">Hours</TableHead>
                <TableHead className="text-right">%</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {studentStats.map((s: any, i: number) => (
                <TableRow key={s.student_id}>
                  <TableCell>{i + 1}</TableCell>
                  <TableCell className="font-medium">{s.student_name}</TableCell>
                  <TableCell>{s.student_no}</TableCell>
                  <TableCell>{s.department_name}</TableCell>
                  <TableCell>{s.semester}</TableCell>
                  <TableCell className="text-xs text-muted-foreground max-w-xs">{selectedCourseName || "All courses"}</TableCell>
                  <TableCell className="text-right text-emerald-600">{s.present}</TableCell>
                  <TableCell className="text-right text-destructive">{s.absent}</TableCell>
                  <TableCell className="text-right whitespace-nowrap">
                    {hoursPerPeriod != null ? `${fmtH(Number(s.present) * hoursPerPeriod)} / ${fmtH(Number(s.total) * hoursPerPeriod)} h` : "—"}
                  </TableCell>
                  <TableCell className="text-right">{s.total ? `${s.pct}%` : "—"}</TableCell>
                  <TableCell className="text-right">
                    {Number(s.total) > 0 && Number(s.pct) < limit && <Badge variant="destructive">High absence</Badge>}
                  </TableCell>
                </TableRow>
              ))}
              {!studentStats.length && (
                <TableRow><TableCell colSpan={11} className="text-center text-muted-foreground py-8">
                  {reportLoading ? "Loading…" : "No students or attendance records match these filters."}
                </TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card className="border-border/60 rounded-2xl" style={{ boxShadow: "var(--shadow-card)" }}>
        <CardContent className="p-0">
          <div className="p-4 border-b"><h3 className="font-semibold text-lg">Course ranking (highest → lowest attendance)</h3></div>
          <Table>
            <TableHeader>
              <TableRow className="bg-accent/60">
                <TableHead>#</TableHead>
                <TableHead>Course</TableHead>
                <TableHead>Lecturer</TableHead>
                <TableHead className="text-right">Present</TableHead>
                <TableHead className="text-right">Absent</TableHead>
                <TableHead className="text-right">%</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {best.slice(0, 30).map((c: any, i: number) => (
                <TableRow key={c.course_id}>
                  <TableCell>{i + 1}</TableCell>
                  <TableCell className="font-medium">{c.course_name}</TableCell>
                  <TableCell>{c.teacher_name ?? "—"}</TableCell>
                  <TableCell className="text-right text-emerald-600">{c.present}</TableCell>
                  <TableCell className="text-right text-destructive">{c.absent}</TableCell>
                  <TableCell className="text-right">{c.pct}%</TableCell>
                </TableRow>
              ))}
              {!courseStats.length && (
                <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">No course data in this range.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card className="border-border/60 rounded-2xl" style={{ boxShadow: "var(--shadow-card)" }}>
        <CardContent className="p-5 space-y-3">
          <h3 className="font-semibold text-lg capitalize">{view} trend</h3>
          {chartData.length ? (
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="label" fontSize={11} />
                  <YAxis fontSize={11} />
                  <Tooltip />
                  <Bar dataKey="present" fill="#059669" name="Present" radius={[3, 3, 0, 0]} />
                  <Bar dataKey="absent" fill="#dc2626" name="Absent" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground py-8 text-center">No attendance data in this range.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
