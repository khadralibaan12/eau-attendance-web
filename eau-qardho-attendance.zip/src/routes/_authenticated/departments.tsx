import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Link } from "@tanstack/react-router";
import { Cpu, Landmark, BookMarked, Heart, Building2, Leaf, Stethoscope, Users, Wheat, Baby, Utensils, GraduationCap, ChevronRight } from "lucide-react";

export const Route = createFileRoute("/_authenticated/departments")({
  staticData: { sitemap: false },
  head: () => ({ meta: [
    {"title": "Departments \u2014 EAU Gardo"},
    {"name": "description", "content": "Explore EAU Gardo faculties, students and courses across eight semesters."},
    {"property": "og:title", "content": "Departments \u2014 EAU Gardo"},
    {"property": "og:description", "content": "Explore EAU Gardo faculties, students and courses across eight semesters."},
    {"property": "og:type", "content": "website"},
    {"name": "twitter:card", "content": "summary"},
  ] }),
  component: DepartmentsPage,
});

const PALETTE = [
  { grad: "from-indigo-500 to-blue-600", Icon: Cpu },
  { grad: "from-emerald-500 to-teal-600", Icon: Landmark },
  { grad: "from-orange-500 to-amber-600", Icon: BookMarked },
  { grad: "from-pink-500 to-rose-600", Icon: Heart },
  { grad: "from-sky-500 to-cyan-600", Icon: Building2 },
  { grad: "from-green-500 to-lime-600", Icon: Leaf },
  { grad: "from-red-500 to-rose-700", Icon: Stethoscope },
  { grad: "from-violet-500 to-purple-600", Icon: Users },
  { grad: "from-yellow-500 to-orange-600", Icon: Wheat },
  { grad: "from-fuchsia-500 to-pink-600", Icon: Baby },
  { grad: "from-teal-500 to-emerald-600", Icon: Utensils },
  { grad: "from-blue-500 to-indigo-700", Icon: GraduationCap },
];

function DepartmentsPage() {
  const [rows, setRows] = useState<any[]>([]);
  const [counts, setCounts] = useState<Record<string, { students: number; courses: number }>>({});
  useEffect(() => {
    (async () => {
      const { data: depts } = await supabase.from("departments").select("*").order("name");
      setRows(depts ?? []);
      // Count-only queries keep this page fast (no row payloads transferred).
      const results = await Promise.all(
        (depts ?? []).map(async (d) => {
          const [s, c] = await Promise.all([
            supabase.from("students").select("id", { count: "exact", head: true }).eq("department_id", d.id),
            supabase.from("courses").select("id", { count: "exact", head: true }).eq("department_id", d.id),
          ]);
          return [d.id, { students: s.count ?? 0, courses: c.count ?? 0 }] as const;
        }),
      );
      setCounts(Object.fromEntries(results));
    })();
  }, []);
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl font-bold">Departments</h1>
        <p className="text-muted-foreground mt-1">{rows.length} departments — semester 1 to 8.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
        {rows.map((d, i) => {
          const p = PALETTE[i % PALETTE.length];
          const c = counts[d.id] ?? { students: 0, courses: 0 };
          const Icon = p.Icon;
          return (
            <Link
              key={d.id}
              to="/department/$deptId"
              params={{ deptId: d.id }}
              className="block rounded-2xl overflow-hidden bg-card border border-border/60 shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition-all"
            >
              <div className={`bg-gradient-to-br ${p.grad} p-5 text-white relative`}>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-11 w-11 rounded-xl bg-white/20 grid place-items-center backdrop-blur-sm">
                      <Icon className="h-6 w-6" />
                    </div>
                    <span className="px-2.5 py-1 rounded-md bg-white/20 text-xs font-semibold tracking-wide">{d.code}</span>
                  </div>
                  <ChevronRight className="h-5 w-5 opacity-80" />
                </div>
                <div className="mt-6">
                  <div className="text-xl font-bold leading-tight">{d.name}</div>
                  <div className="text-xs text-white/85 mt-1">Faculty of {d.name}</div>
                </div>
              </div>
              <div className="p-4 flex flex-wrap gap-2">
                <span className="px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-medium">{c.students} students</span>
                <span className="px-3 py-1 rounded-full bg-sky-50 text-sky-700 text-xs font-medium">{c.courses} courses</span>
                <span className="px-3 py-1 rounded-full bg-violet-50 text-violet-700 text-xs font-medium">8 semesters</span>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}