import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

const SUPPORT_NAME = "Eng. Khadra Liban Jama Rabax";
const SUPPORT_PHONE = "+252906943912";
const SUPPORT_WHATSAPP = "252906943912";
const SUPPORT_EMAIL = "Khadralibaan12@gmail.com";

function buildText(r: { name: string; contact: string; category: string; message: string }) {
  return `EAU Gardo Attendance – Support report\nName: ${r.name}\nContact: ${r.contact || "-"}\nCategory: ${r.category}\n\n${r.message}`;
}

export const Route = createFileRoute("/_authenticated/help")({
  staticData: { sitemap: false },
  head: () => ({
    meta: [
      { title: "Help & Support — EAU Gardo Attendance" },
      { name: "description", content: "Contact support and report problems in the EAU Gardo attendance system." },
      { property: "og:title", content: "Help & Support — EAU Gardo Attendance" },
      { property: "og:description", content: "Contact support and report problems in the EAU Gardo attendance system." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: HelpPage,
});

function HelpPage() {
  const [name, setName] = useState("");
  const [contact, setContact] = useState("");
  const [category, setCategory] = useState("Bug");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || message.trim().length < 5) {
      toast.error("Please enter your name and describe the problem.");
      return;
    }
    setBusy(true);
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) { setBusy(false); toast.error("Please sign in again."); return; }
    const { error } = await supabase.from("support_reports").insert({
      user_id: u.user.id, name: name.trim(), contact: contact.trim() || null, category, message: message.trim(),
    });
    setBusy(false);
    if (error) { toast.error("Could not send report: " + error.message); return; }
    setSent(buildText({ name: name.trim(), contact: contact.trim(), category, message: message.trim() }));
    toast.success("Report saved. Now send it to support via WhatsApp or Gmail.");
    setMessage("");
  }

  const waUrl = sent ? `https://wa.me/${SUPPORT_WHATSAPP}?text=${encodeURIComponent(sent)}` : "";
  const gmailUrl = sent
    ? `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(SUPPORT_EMAIL)}&su=${encodeURIComponent("EAU Attendance support report")}&body=${encodeURIComponent(sent)}`
    : "";

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-3xl font-bold">Help & Support</h1>
        <p className="text-muted-foreground mt-1">East Africa University – Gardo Campus (EAU Gardo)</p>
      </div>

      <Card className="border-border/60 rounded-2xl" style={{ boxShadow: "var(--shadow-card)" }}>
        <CardContent className="p-5 flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">System Support</div>
            <div className="text-xl font-bold mt-1">{SUPPORT_NAME}</div>
            <div className="text-muted-foreground">Phone: {SUPPORT_PHONE}</div>
          </div>
          <Button asChild size="lg"><a href={`tel:${SUPPORT_PHONE}`}>Call Support</a></Button>
        </CardContent>
      </Card>

      <Card className="border-border/60 rounded-2xl" style={{ boxShadow: "var(--shadow-card)" }}>
        <CardContent className="p-5">
          <h3 className="font-semibold text-lg mb-3">Report a problem</h3>
          <form onSubmit={submit} className="space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <Input placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} />
              <Input placeholder="Phone or email (optional)" value={contact} onChange={(e) => setContact(e.target.value)} />
            </div>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {["Bug", "Wrong attendance data", "Login problem", "Report / export", "Other"].map((c) => (
                  <SelectItem key={c} value={c}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Textarea rows={5} placeholder="Describe the problem…" value={message} onChange={(e) => setMessage(e.target.value)} />
            <Button type="submit" disabled={busy}>{busy ? "Sending…" : "Send report"}</Button>
          </form>
          {sent && (
            <div className="mt-4 rounded-xl border border-primary/40 bg-primary/5 p-4 space-y-3">
              <p className="text-sm font-medium">Report saved. Send it now to support:</p>
              <div className="flex flex-wrap gap-2">
                <Button asChild><a href={waUrl} target="_blank" rel="noopener noreferrer">Send via WhatsApp</a></Button>
                <Button asChild variant="outline"><a href={gmailUrl} target="_blank" rel="noopener noreferrer">Send via Gmail</a></Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
