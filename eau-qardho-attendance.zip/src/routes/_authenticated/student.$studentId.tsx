import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { attendedHours, CLASS_TIME_LABEL } from "@/lib/schedule";

export const Route = createFileRoute("/_authenticated/student/$studentId")({
  staticData: { sitemap: false },
  head: () => ({ meta: [
    {"title": "Student Attendance History \u2014 EAU Gardo"},
    {"name": "description", "content": "View individual student attendance, monthly summaries and attended hours at EAU Gardo."},
    {"property": "og:title", "content": "Student Attendance History \u2014 EAU Gardo"},
    {"property": "og:description", "content": "View individual student attendance, monthly summaries and attended hours at EAU Gardo."},
    {"property": "og:type", "content": "website"},
    {"name": "twitter:card", "content": "summary"},
  ] }),
  component: StudentHistoryPage,
});

function StudentHistoryPage() {
  const { studentId } = Route.useParams();
  const [openMonth, setOpenMonth] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [courseFilter, setCourseFilter] = useState("");

  const { data: student } = useQuery({
    queryKey: ["student", studentId],
    queryFn: async () => {
      const { data } = await supabase
        .from("students")
        .select("id, full_name, student_no, semester, class_code, departments(name, code)")
        .eq("id", studentId)
        .maybeSingle();
      return data;
    },
  });

  const { data: summary = [] } = useQuery({
    queryKey: ["student-summary", studentId],
    queryFn: async () => {
      const { data } = await supabase.rpc("student_attendance_summary", { p_student: studentId });
      return data ?? [];
    },
  });

  const { data: records = [], isLoading } = useQuery({
    queryKey: ["student-records", studentId, fromDate, toDate, courseFilter],
    queryFn: async () => {
      let q = supabase
        .from("attendance")
        .select("date, status, remarks, recorded_at, course_id, courses(name), teachers(full_name)")
        .eq("student_id", studentId)
        .order("date", { ascending: false })
        .limit(3000);
      if (fromDate) q = q.gte("date", fromDate);
      if (toDate) q = q.lte("date", toDate);
      if (courseFilter) q = q.eq("course_id", courseFilter);
      const { data } = await q;
      return data ?? [];
    },
  });

  const { data: studentCourses = [] } = useQuery({
    queryKey: ["student-course-list", studentId],
    queryFn: async () => {
      const { data } = await supabase.rpc("student_attendance_summary", { p_student: studentId });
      return (data ?? []) as any[];
    },
  });

  const totals = useMemo(() => {
    const present = records.filter((r: any) => r.status === "present" || r.status === "late").length;
    const absent = records.filter((r: any) => r.status === "absent").length;
    const excused = records.filter((r: any) => r.status === "excused").length;
    const total = present + absent + excused;
    return { present, absent, excused, pct: total ? Math.round((present / total) * 100) : 0 };
  }, [records]);

  const months = useMemo(() => {
    const map = new Map<string, { key: string; label: string; present: number; absent: number; excused: number; rows: any[] }>();
    records.forEach((r: any) => {
      const key = String(r.date).slice(0, 7);
      const m =
        map.get(key) ??
        {
          key,
          label: new Date(`${key}-01T00:00:00`).toLocaleDateString(undefined, { month: "long", year: "numeric" }),
          present: 0,
          absent: 0,
          excused: 0,
          rows: [] as any[],
        };
      if (r.status === "present" || r.status === "late") m.present++;
      else if (r.status === "absent") m.absent++;
      else if (r.status === "excused") m.excused++;
      m.rows.push(r);
      map.set(key, m);
    });
    return [...map.values()].sort((a, b) => (a.key < b.key ? 1 : -1));
  }, [records]);

  function printReport(title: string, list: any[], p: number, a: number, ex: number) {
    const w = window.open("", "_blank");
    if (!w) return;
    const esc = (v: unknown) => String(v ?? "").replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]!));
    const t = p + a + ex;
    const rows = list
      .map(
        (r: any) => `<tr><td>${r.date}</td><td>${esc(r.courses?.name)}</td><td>${esc(r.teachers?.full_name ?? "—")}</td><td style="text-transform:capitalize">${r.status}</td><td>${esc(r.remarks)}</td></tr>`,
      )
      .join("");
    w.document.write(`<!doctype html><html><head><title>${esc(title)}</title><style>
      body{font-family:Arial,sans-serif;padding:24px;color:#0f172a}
      h1{font-size:20px;margin:0 0 4px}.sub{color:#64748b;font-size:12px;margin-bottom:16px}
      table{width:100%;border-collapse:collapse;font-size:12px}
      th,td{border:1px solid #e2e8f0;padding:6px 8px;text-align:left}
      th{background:#dbeafe;color:#1e3a8a}
    </style></head><body>
      <div class="sub">EAU Gardo — East Africa University Gardo</div>
      <h1>${esc(student?.full_name ?? "Student")} — ${esc(title)}</h1>
      <div class="sub">${esc(student?.student_no)} · ${esc(student?.class_code)} · Days present ${p} · Days absent ${a} · Excused ${ex} · Hours attended ${attendedHours(p)} h · ${t ? Math.round((p / t) * 100) : 0}% · Class time ${CLASS_TIME_LABEL}</div>
      <table><thead><tr><th>Date</th><th>Course</th><th>Teacher</th><th>Status</th><th>Remarks</th></tr></thead><tbody>${rows}</tbody></table>
      <script>window.onload=()=>window.print()</script></body></html>`);
    w.document.close();
  }

  function exportPdf() {
    printReport("Attendance History", records, totals.present, totals.absent, totals.excused);
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold">{student?.full_name ?? "Student"}</h1>
          <p className="text-muted-foreground mt-1">
            {student?.student_no ?? ""} · {(student as any)?.departments?.name ?? ""} · Semester {student?.semester ?? "—"}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" asChild><Link to="/students">Back to students</Link></Button>
          <Button onClick={exportPdf} disabled={!records.length}>Export PDF</Button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {[
          { label: "Days present", value: totals.present },
          { label: "Days absent", value: totals.absent },
          { label: "Excused", value: totals.excused },
          { label: "Hours attended", value: `${attendedHours(totals.present)} h` },
          { label: "Attendance %", value: `${totals.pct}%` },
        ].map((s) => (
          <Card key={s.label} className="border-border/60 rounded-2xl" style={{ boxShadow: "var(--shadow-card)" }}>
            <CardContent className="p-5">
              <div className="text-sm text-muted-foreground">{s.label}</div>
              <div className="text-4xl font-bold mt-2">{s.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-border/60 rounded-2xl" style={{ boxShadow: "var(--shadow-card)" }}>
        <CardContent className="p-0">
          <div className="p-4 border-b"><h3 className="font-semibold text-lg">By course</h3></div>
          <Table>
            <TableHeader>
              <TableRow className="bg-accent/60">
                <TableHead>Course</TableHead>
                <TableHead>Teacher</TableHead>
                <TableHead className="text-right">Present</TableHead>
                <TableHead className="text-right">Absent</TableHead>
                <TableHead className="text-right">%</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(summary as any[]).map((c) => {
                const t = Number(c.present) + Number(c.absent);
                return (
                  <TableRow key={c.course_id}>
                    <TableCell className="font-medium">{c.course_name}</TableCell>
                    <TableCell>{c.teacher_name ?? "—"}</TableCell>
                    <TableCell className="text-right text-emerald-600">{c.present}</TableCell>
                    <TableCell className="text-right text-destructive">{c.absent}</TableCell>
                    <TableCell className="text-right">{t ? Math.round((Number(c.present) / t) * 100) : 0}%</TableCell>
                  </TableRow>
                );
              })}
              {!summary.length && (
                <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                  {isLoading ? "Loading…" : "No attendance recorded yet."}
                </TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card className="border-border/60 rounded-2xl" style={{ boxShadow: "var(--shadow-card)" }}>
        <CardContent className="p-4 grid grid-cols-1 md:grid-cols-3 gap-3">
          <div>
            <div className="text-xs font-medium text-muted-foreground mb-1.5">From</div>
            <Input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} />
          </div>
          <div>
            <div className="text-xs font-medium text-muted-foreground mb-1.5">To</div>
            <Input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} />
          </div>
          <div>
            <div className="text-xs font-medium text-muted-foreground mb-1.5">Course</div>
            <Select value={courseFilter} onValueChange={(v) => setCourseFilter(v === "all" ? "" : v)}>
              <SelectTrigger><SelectValue placeholder="All courses" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All courses</SelectItem>
                {studentCourses.map((c: any) => <SelectItem key={c.course_id} value={c.course_id}>{c.course_name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border/60 rounded-2xl" style={{ boxShadow: "var(--shadow-card)" }}>
        <CardContent className="p-0">
          <div className="p-4 border-b"><h3 className="font-semibold text-lg">Monthly report</h3></div>
          <div className="divide-y">
            {months.map((m) => {
              const open = openMonth === m.key;
              const t = m.present + m.absent + m.excused;
              return (
                <div key={m.key}>
                  <button onClick={() => setOpenMonth(open ? "" : m.key)} className="w-full text-left px-4 py-3 hover:bg-accent/50 transition">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-semibold">{m.label}</span>
                      <span className="text-sm text-muted-foreground">{t ? Math.round((m.present / t) * 100) : 0}%</span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      <span className="text-emerald-600 font-medium">{m.present} days present</span> ·{" "}
                      <span className="text-destructive font-medium">{m.absent} days absent</span> ·{" "}
                      <span className="text-amber-600 font-medium">{m.excused} excused</span> ·{" "}
                      <span className="font-medium">{attendedHours(m.present)} hours</span>
                    </div>
                  </button>
                  {open && (
                    <div className="bg-accent/20 px-4 pb-3">
                      <div className="flex justify-end py-2">
                        <Button size="sm" variant="outline" onClick={() => printReport(`Monthly Report · ${m.label}`, m.rows, m.present, m.absent, m.excused)}>
                          Print monthly report
                        </Button>
                      </div>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Date</TableHead>
                            <TableHead>Course</TableHead>
                            <TableHead>Teacher</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Remarks</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {m.rows.map((r: any, i: number) => (
                            <TableRow key={`${r.date}-${i}`}>
                              <TableCell>{r.date}</TableCell>
                              <TableCell>{r.courses?.name ?? "—"}</TableCell>
                              <TableCell>{r.teachers?.full_name ?? "—"}</TableCell>
                              <TableCell>
                                <Badge variant={r.status === "absent" ? "destructive" : r.status === "excused" ? "outline" : "secondary"} className="capitalize">{r.status}</Badge>
                              </TableCell>
                              <TableCell className="text-xs text-muted-foreground">{r.remarks ?? "—"}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </div>
              );
            })}
            {!months.length && (
              <div className="text-center text-muted-foreground py-8 text-sm">
                {isLoading ? "Loading history…" : "No attendance saved for this student yet."}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <ChangeLog studentId={studentId} />
    </div>
  );
}

function ChangeLog({ studentId }: { studentId: string }) {
  const { data: logs = [], isLoading } = useQuery({
    queryKey: ["student-log", studentId],
    queryFn: async () => {
      const { data } = await supabase
        .from("attendance_log")
        .select("id, date, semester, old_status, new_status, action, changed_at, courses(name)")
        .eq("student_id", studentId)
        .order("changed_at", { ascending: false })
        .limit(500);
      return data ?? [];
    },
  });
  return (
    <Card className="border-border/60 rounded-2xl" style={{ boxShadow: "var(--shadow-card)" }}>
      <CardContent className="p-0">
        <div className="p-4 border-b">
          <h3 className="font-semibold text-lg">Saved records log (old and new)</h3>
          <p className="text-xs text-muted-foreground">Every save and every change is kept permanently.</p>
        </div>
        <Table>
          <TableHeader>
            <TableRow className="bg-accent/60">
              <TableHead>Saved at</TableHead>
              <TableHead>Class date</TableHead>
              <TableHead>Semester</TableHead>
              <TableHead>Course</TableHead>
              <TableHead>Old</TableHead>
              <TableHead>New</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {(logs as any[]).map((l) => (
              <TableRow key={l.id}>
                <TableCell className="text-xs">{new Date(l.changed_at).toLocaleString()}</TableCell>
                <TableCell>{l.date}</TableCell>
                <TableCell>{l.semester ?? "—"}</TableCell>
                <TableCell>{l.courses?.name ?? "—"}</TableCell>
                <TableCell className="capitalize text-muted-foreground">{l.old_status ?? "—"}</TableCell>
                <TableCell className="capitalize font-medium">{l.new_status ?? "deleted"}</TableCell>
              </TableRow>
            ))}
            {!logs.length && (
              <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                {isLoading ? "Loading…" : "No saved records yet."}
              </TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
