import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { coursesCatalogueOptions } from "@/lib/catalogue.queries";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/courses")({
  staticData: { sitemap: false },
  head: () => ({ meta: [
    {"title": "Course Management \u2014 EAU Gardo"},
    {"name": "description", "content": "Manage EAU Gardo courses and lecturer assignments by faculty and semester."},
    {"property": "og:title", "content": "Course Management \u2014 EAU Gardo"},
    {"property": "og:description", "content": "Manage EAU Gardo courses and lecturer assignments by faculty and semester."},
    {"property": "og:type", "content": "website"},
    {"name": "twitter:card", "content": "summary"},
  ] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(coursesCatalogueOptions(context.user.id)),
  component: CoursesPage,
});

type CourseForm = {
  id?: string;
  name: string;
  code: string;
  department_id: string;
  semester: string;
  teacher_id: string;
  credit_hours: string;
};

const emptyForm: CourseForm = { name: "", code: "", department_id: "", semester: "3", teacher_id: "", credit_hours: "4" };

function CoursesPage() {
  const { user } = Route.useRouteContext();
  const queryClient = useQueryClient();
  const { data: { depts, teachers, rows } } = useSuspenseQuery(coursesCatalogueOptions(user.id));
  const [q, setQ] = useState("");
  const [department, setDepartment] = useState("all");
  const [semester, setSemester] = useState("all");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<CourseForm>(emptyForm);
  const [saving, setSaving] = useState(false);

  const load = () => queryClient.invalidateQueries({ queryKey: ["catalogue"] });

  const openAdd = (deptId?: string, semester?: number) => {
    setForm({ ...emptyForm, department_id: deptId ?? depts[0]?.id ?? "", semester: String(semester ?? 3) });
    setOpen(true);
  };

  const openEdit = (c: any) => {
    setForm({
      id: c.id,
      name: c.name ?? "",
      code: c.code ?? "",
      department_id: c.department_id,
      semester: String(c.semester),
      teacher_id: c.teacher_id ?? "",
      credit_hours: c.credit_hours == null ? "" : String(c.credit_hours),
    });
    setOpen(true);
  };

  const save = async () => {
    if (!form.name.trim() || !form.department_id) {
      toast.error("Course name and department are required.");
      return;
    }
    setSaving(true);
    if (form.credit_hours && (!Number.isFinite(Number(form.credit_hours)) || Number(form.credit_hours) <= 0)) {
      setSaving(false);
      toast.error("Credit hours must be greater than zero.");
      return;
    }
    const payload = {
      name: form.name.trim(),
      code: form.code.trim() || null,
      department_id: form.department_id,
      semester: Number(form.semester),
      teacher_id: form.teacher_id || null,
      credit_hours: form.credit_hours ? Number(form.credit_hours) : null,
    };
    const { error } = form.id
      ? await supabase.from("courses").update(payload).eq("id", form.id)
      : await supabase.from("courses").insert(payload);
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(form.id ? "Course updated" : "Course added");
    setOpen(false);
    load();
  };

  const remove = async (c: any) => {
    if (!confirm(`Delete "${c.name}"?`)) return;
    const { error } = await supabase.from("courses").delete().eq("id", c.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Course deleted");
    load();
  };

  const grouped = useMemo(() => {
    const query = q.toLowerCase().trim();
    return depts.filter(d => department === "all" || d.id === department).map(dept => ({
      dept,
      courses: rows.filter(c => c.department_id === dept.id
        && (semester === "all" || String(c.semester) === semester)
        && (!query || [c.name, c.code, c.teachers?.full_name, dept.name, dept.code]
          .some(value => String(value ?? "").toLowerCase().includes(query)))),
    })).filter(group => group.courses.length > 0);
  }, [depts, rows, q, department, semester]);
  const shownCount = grouped.reduce((total, group) => total + group.courses.length, 0);

  return (
    <div className="space-y-8 min-w-0 catalogue-page">
      <div className="flex flex-wrap items-end justify-between gap-4 border-b-2 border-primary pb-6">
        <div>
          <p className="text-sm font-medium text-primary mb-2">EAU Gardo · Course catalogue</p>
          <h1 className="text-3xl font-bold">Courses</h1>
          <p className="text-muted-foreground mt-2">{rows.length} courses · {depts.length} departments</p>
        </div>
        <Button onClick={() => openAdd(department === "all" ? undefined : department, semester === "all" ? undefined : Number(semester))}>Add Course</Button>
      </div>

      <div className="flex flex-col gap-4">
        <div className="grid gap-3 max-w-2xl">
          <Label>Department</Label>
          <Select value={department} onValueChange={setDepartment}>
            <SelectTrigger aria-label="Filter department" className="w-full bg-card"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All departments</SelectItem>
              {depts.map(d => <SelectItem key={d.id} value={d.id}>{d.code} — {d.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Label htmlFor="catalogue-search">Search</Label>
          <Input id="catalogue-search" aria-label="Search courses" placeholder="Search courses or teachers…" value={q} onChange={e => setQ(e.target.value)} className="bg-card" />
        </div>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap gap-1" aria-label="Filter semester">
            {["all", "3", "5", "7"].map(value => <Button key={value} variant={semester === value ? "default" : "ghost"} size="sm" aria-pressed={semester === value} onClick={() => setSemester(value)}>{value === "all" ? "All semesters" : `Semester ${value}`}</Button>)}
          </div>
          <span className="text-sm text-muted-foreground">{shownCount} courses</span>
        </div>
      </div>

      {grouped.length === 0 && <p className="py-12 text-center text-muted-foreground">No courses found.</p>}
      {grouped.map(({ dept, courses }) => (
        <section key={dept.id} className="space-y-6 catalogue-department">
          <header className="flex items-start gap-3 border-b border-border pb-4">
            <span className="bg-primary text-primary-foreground rounded-md px-3 py-2 text-sm font-bold shrink-0">{dept.code}</span>
            <div className="min-w-0"><h2 className="text-xl font-bold break-words">{dept.name}</h2><p className="text-sm text-muted-foreground mt-1">{courses.length} courses</p></div>
          </header>
          {[3, 5, 7].map(s => {
            const semesterCourses = courses.filter(c => c.semester === s);
            if (!semesterCourses.length) return null;
            return <section key={s} aria-label={`${dept.code} Semester ${s}`} className="min-w-0 catalogue-semester">
              <header className="flex flex-wrap items-center justify-between gap-2 border-l-4 border-primary bg-secondary px-4 py-4">
                <h3 className="text-base font-semibold">Semester {s}</h3>
                <span className="text-sm text-muted-foreground">{semesterCourses.length} courses</span>
              </header>
              <div role="table" aria-label={`${dept.code} Semester ${s} courses`}>
                <div role="row" className="hidden md:grid grid-cols-[minmax(0,2fr)_minmax(0,1.4fr)_7rem_8rem] items-center gap-4 border-b border-border px-4 py-3 text-xs font-semibold uppercase text-muted-foreground">
                  <span role="columnheader">Course</span><span role="columnheader">Assigned teacher</span><span role="columnheader">Credit hours</span><span role="columnheader" className="text-right">Actions</span>
                </div>
                <div role="rowgroup" className="divide-y divide-border">
                  {semesterCourses.map((c, index) => <div role="row" key={c.id} className="grid grid-cols-1 md:grid-cols-[minmax(0,2fr)_minmax(0,1.4fr)_7rem_8rem] items-center gap-3 md:gap-4 px-4 py-5 transition-colors hover:bg-accent/30 even:bg-muted/40">
                    <div role="cell" className="flex items-start gap-3 min-w-0">
                      <span className="text-xs tabular-nums text-primary font-semibold pt-1 w-5 shrink-0">{String(index + 1).padStart(2, "0")}</span>
                      <div className="min-w-0"><h4 className="font-semibold leading-snug break-words">{c.name}</h4>{c.code && <p className="text-xs text-muted-foreground mt-1 break-words">{c.code}</p>}</div>
                    </div>
                    <div role="cell" className="min-w-0 pl-8 md:pl-0"><span className="md:hidden block text-xs text-muted-foreground mb-1">Assigned teacher</span><p className="text-sm break-words">{c.teachers?.full_name ?? "Unassigned"}</p></div>
                    <div role="cell" className="pl-8 md:pl-0 text-sm"><span className="md:hidden text-muted-foreground mr-2">Credit hours:</span><span className="font-semibold tabular-nums">{c.credit_hours == null ? "Not specified" : `${c.credit_hours} hours`}</span></div>
                    <div role="cell" className="flex justify-end gap-1">
                      <Button variant="outline" size="sm" aria-label={`Edit ${c.name}`} onClick={() => openEdit(c)}>Edit</Button>
                      <Button variant="ghost" size="sm" className="text-destructive" aria-label={`Delete ${c.name}`} onClick={() => remove(c)}>Delete</Button>
                    </div>
                  </div>)}
                </div>
              </div>
            </section>;
          })}
        </section>
      ))}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{form.id ? "Edit Course" : "Add Course"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="course-name">Course name</Label>
              <Input id="course-name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="course-code">Course code</Label>
              <Input id="course-code" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="credit-hours">Credit hours</Label>
              <Input id="credit-hours" type="number" min="0.1" step="0.1" value={form.credit_hours} onChange={(e) => setForm({ ...form, credit_hours: e.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Department</Label>
                <Select value={form.department_id} onValueChange={(v) => setForm({ ...form, department_id: v })}>
                  <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    {depts.map((d) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Semester</Label>
                <Select value={form.semester} onValueChange={(v) => setForm({ ...form, semester: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {[3, 5, 7].map((s) => (
                      <SelectItem key={s} value={String(s)}>Semester {s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Teacher</Label>
              <Select value={form.teacher_id || "none"} onValueChange={(v) => setForm({ ...form, teacher_id: v === "none" ? "" : v })}>
                <SelectTrigger><SelectValue placeholder="Unassigned" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Unassigned</SelectItem>
                  {teachers.map((t) => <SelectItem key={t.id} value={t.id}>{t.full_name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving ? "Saving…" : "Save"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}