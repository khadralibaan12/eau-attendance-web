import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { UserPlus, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/students")({
  staticData: { sitemap: false },
  head: () => ({ meta: [
    { title: "Student Management — EAU Gardo" },
    { name: "description", content: "Manage East Africa University Gardo students by faculty and semester and view their attendance history." },
    { property: "og:title", content: "Student Management — EAU Gardo" },
    { property: "og:description", content: "Student rosters and attendance history by faculty and semester at EAU Gardo." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: StudentsPage,
});

function StudentsPage() {
  const [depts, setDepts] = useState<any[]>([]);
  const [dept, setDept] = useState<string>("all");
  const [sem, setSem] = useState<string>("all");
  const [q, setQ] = useState("");
  const [rows, setRows] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState({ full_name: "", gender: "M", department_id: "", semester: "1" });

  useEffect(() => {
    supabase.from("departments").select("*").order("name").then(({ data }) => setDepts(data ?? []));
    supabase.from("students").select("id", { count: "exact", head: true }).then(({ count }) => setTotal(count ?? 0));
  }, []);

  async function load() {
    let query = supabase.from("students").select("*, departments(name, code)").order("full_name").limit(500);
    if (dept !== "all") query = query.eq("department_id", dept);
    if (sem !== "all") query = query.eq("semester", Number(sem));
    const { data } = await query;
    setRows(data ?? []);
  }
  useEffect(() => { load(); }, [dept, sem]);

  const filtered = rows.filter((r) => !q || r.full_name.toLowerCase().includes(q.toLowerCase()) || r.student_no.toLowerCase().includes(q.toLowerCase()));

  function openAdd() {
    setEditing(null);
    setForm({ full_name: "", gender: "M", department_id: depts[0]?.id ?? "", semester: "1" });
    setOpen(true);
  }
  function openEdit(s: any) {
    setEditing(s);
    setForm({ full_name: s.full_name, gender: s.gender, department_id: s.department_id, semester: String(s.semester) });
    setOpen(true);
  }
  async function save() {
    if (!form.full_name.trim() || !form.department_id) { toast.error("Fill all fields"); return; }
    const d = depts.find((x) => x.id === form.department_id);
    if (editing) {
      const { error } = await supabase.from("students").update({
        full_name: form.full_name, gender: form.gender, department_id: form.department_id,
        semester: Number(form.semester), class_code: `${d?.code}${form.semester}`,
      }).eq("id", editing.id);
      if (error) return toast.error(error.message);
    } else {
      const seq = Math.floor(Math.random() * 9000) + 1000;
      const { error } = await supabase.from("students").insert({
        full_name: form.full_name, gender: form.gender, department_id: form.department_id,
        semester: Number(form.semester), class_code: `${d?.code}${form.semester}`,
        student_no: `${d?.code}${form.semester}-${seq}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`,
      });
      if (error) return toast.error(error.message);
    }
    toast.success("Saved");
    setOpen(false);
    load();
  }
  async function remove(s: any) {
    if (!confirm(`Delete ${s.full_name}?`)) return;
    const { error } = await supabase.from("students").delete().eq("id", s.id);
    if (error) return toast.error(error.message);
    toast.success("Deleted");
    load();
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-3">
        <div>
          <h1 className="text-4xl font-bold">Students</h1>
          <p className="text-muted-foreground mt-1">Total: {total.toLocaleString()} students</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={openAdd}>
            <UserPlus className="h-4 w-4 mr-1" /> Add student
          </Button>
        </div>
      </div>

      <Card className="border-border/60 rounded-2xl" style={{ boxShadow: "var(--shadow-card)" }}>
        <CardContent className="p-4 grid grid-cols-1 md:grid-cols-3 gap-3">
          <Select value={dept} onValueChange={setDept}>
            <SelectTrigger><SelectValue placeholder="All Departments" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Departments</SelectItem>
              {depts.map((d) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={sem} onValueChange={setSem}>
            <SelectTrigger><SelectValue placeholder="All Semesters" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Semesters</SelectItem>
              {Array.from({length:8},(_,i)=>i+1).map((s) => <SelectItem key={s} value={String(s)}>Semester {s}</SelectItem>)}
            </SelectContent>
          </Select>
          <Input placeholder="Search by name or ID…" value={q} onChange={(e) => setQ(e.target.value)} />
        </CardContent>
      </Card>

      <Card className="border-border/60 rounded-2xl" style={{ boxShadow: "var(--shadow-card)" }}>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-accent/60">
                <TableHead className="w-16">#</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Class</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((s, i) => (
                <TableRow key={s.id}>
                  <TableCell className="text-muted-foreground">{i + 1}</TableCell>
                  <TableCell className="font-medium">{s.full_name}</TableCell>
                  <TableCell>
                    <span className="px-2.5 py-1 rounded-md bg-accent text-primary text-xs font-semibold">{s.class_code}</span>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Link
                        to="/student/$studentId"
                        params={{ studentId: s.id }}
                        className="h-8 px-3 grid place-items-center rounded-md text-xs font-medium text-primary hover:bg-accent"
                      >
                        History
                      </Link>
                      <button onClick={() => openEdit(s)} className="h-8 w-8 grid place-items-center rounded-md text-primary hover:bg-accent" aria-label="Edit">
                        <Pencil className="h-4 w-4" />
                      </button>
                      <button onClick={() => remove(s)} className="h-8 w-8 grid place-items-center rounded-md text-destructive hover:bg-destructive/10" aria-label="Delete">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {filtered.length === 0 && (
                <TableRow><TableCell colSpan={4} className="text-center text-muted-foreground py-8">No students found.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Edit student" : "Add student"}</DialogTitle></DialogHeader>
          <div className="grid gap-3">
            <Input placeholder="Full name" value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} />
            <Select value={form.gender} onValueChange={(v) => setForm({ ...form, gender: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="M">Male</SelectItem>
                <SelectItem value="F">Female</SelectItem>
              </SelectContent>
            </Select>
            <Select value={form.department_id} onValueChange={(v) => setForm({ ...form, department_id: v })}>
              <SelectTrigger><SelectValue placeholder="Department" /></SelectTrigger>
              <SelectContent>
                {depts.map((d) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={form.semester} onValueChange={(v) => setForm({ ...form, semester: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {Array.from({length:8},(_,i)=>i+1).map((s) => <SelectItem key={s} value={String(s)}>Semester {s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save}>{editing ? "Save changes" : "Add student"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}