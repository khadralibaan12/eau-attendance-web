import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { teachersCatalogueOptions } from "@/lib/catalogue.queries";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { upsertTeacherLogin } from "@/lib/teacher-accounts.functions";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/teachers")({
  staticData: { sitemap: false },
  head: () => ({ meta: [
    {"title": "Teachers \u2014 EAU Gardo"},
    {"name": "description", "content": "Manage lecturers and their assigned teaching details at EAU Gardo."},
    {"property": "og:title", "content": "Teachers \u2014 EAU Gardo"},
    {"property": "og:description", "content": "Manage lecturers and their assigned teaching details at EAU Gardo."},
    {"property": "og:type", "content": "website"},
    {"name": "twitter:card", "content": "summary"},
  ] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(teachersCatalogueOptions(context.user.id)),
  component: TeachersPage,
});

// Fixed, never-shuffled order for the first five (plus Calculus) teachers.
const PINNED_NAMES = [
  "Eng. Daud Nuux",
  "Eng. Abdifatah Gaata",
  "Mr. Abshir Gurey",
  "Mr. Mohamed Isxaaq",
  "Sheikh Adan",
  "Mr. Sharma Qaal",
];

function TeacherTable({
  rows,
  startIndex = 0,
  onEdit,
  onDelete,
  onLogin,
}: {
  rows: any[];
  startIndex?: number;
  onEdit: (t: any) => void;
  onDelete: (t: any) => void;
  onLogin: (t: any) => void;
}) {
  return (
    <div role="table" aria-label="Teacher assignments">
      <div role="row" className="hidden lg:grid grid-cols-[3rem_minmax(0,1.1fr)_minmax(0,1.8fr)_minmax(0,1fr)] gap-5 bg-secondary px-5 py-3 text-xs font-semibold uppercase text-muted-foreground">
        <span role="columnheader">#</span><span role="columnheader">Teacher</span><span role="columnheader">Courses</span><span role="columnheader">Contact & access</span>
      </div>
      {rows.map((t, i) => (
        <div role="row" key={t.id} className="grid grid-cols-1 lg:grid-cols-[3rem_minmax(0,1.1fr)_minmax(0,1.8fr)_minmax(0,1fr)] gap-5 px-5 py-6 border-b-2 border-primary even:bg-muted/40">
          <div role="cell" className="text-primary text-sm font-bold tabular-nums">{String(startIndex + i + 1).padStart(2, "0")}</div>
          <div role="cell" className="min-w-0">
            <h2 className="font-bold text-lg break-words">{t.full_name}</h2>
            <p className="text-sm text-muted-foreground mt-1">{t.assignedCourses?.length ?? 0} assigned courses</p>
            <div className="flex flex-wrap gap-1 mt-4">
              <Button variant="outline" size="sm" onClick={() => onEdit(t)}>Edit</Button>
              <Button variant="ghost" size="sm" className="text-destructive" onClick={() => onDelete(t)}>Delete</Button>
            </div>
          </div>
          <div role="cell" className="min-w-0">
            <span className="lg:hidden block text-xs font-semibold uppercase text-muted-foreground mb-3">Courses</span>
            {t.assignedCourses?.length ? <ul className="divide-y divide-border">{t.assignedCourses.map((course: any) => <li key={course.id} className="py-2 first:pt-0"><span className="text-sm font-medium break-words">{course.name}</span><span className="block text-xs text-muted-foreground mt-1">{course.departmentCode} · Semester {course.semester}</span></li>)}</ul> : <span className="text-sm text-muted-foreground">No assigned courses</span>}
          </div>
          <div role="cell" className="min-w-0 space-y-2">
            <p className="text-sm break-words">{t.email ?? "—"}</p>
            <p className="text-sm text-muted-foreground break-words">{t.phone ?? "—"}</p>
            <Badge variant="secondary">{t.user_id ? "Login enabled" : "Login not set"}</Badge>
            <div className="pt-2"><Button variant="outline" size="sm" onClick={() => onLogin(t)}>Login access</Button></div>
          </div>
        </div>
      ))}
      {rows.length === 0 && <p className="text-center text-muted-foreground py-12">No teachers found.</p>}
    </div>
  );
}

function TeachersPage() {
  const { user } = Route.useRouteContext();
  const queryClient = useQueryClient();
  const { data: rows } = useSuspenseQuery(teachersCatalogueOptions(user.id));
  const createLogin = useServerFn(upsertTeacherLogin);
  const [loginFor, setLoginFor] = useState<any | null>(null);
  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [loginSaving, setLoginSaving] = useState(false);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);
  const [form, setForm] = useState({ full_name: "", specialty: "", email: "", phone: "" });
  const [saving, setSaving] = useState(false);

  const load = () => queryClient.invalidateQueries({ queryKey: ["catalogue"] });

  function openNew() {
    setEditing(null);
    setForm({ full_name: "", specialty: "", email: "", phone: "" });
    setOpen(true);
  }
  function openEdit(t: any) {
    setEditing(t);
    setForm({ full_name: t.full_name ?? "", specialty: t.specialty ?? "", email: t.email ?? "", phone: t.phone ?? "" });
    setOpen(true);
  }
  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!form.full_name.trim()) return toast.error("Full name is required");
    setSaving(true);
    const payload = {
      full_name: form.full_name.trim(),
      specialty: form.specialty.trim() || null,
      email: form.email.trim() || null,
      phone: form.phone.trim() || null,
    };
    const { error } = editing
      ? await supabase.from("teachers").update(payload).eq("id", editing.id)
      : await supabase.from("teachers").insert(payload);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success(editing ? "Teacher updated" : "Teacher added");
    setOpen(false);
    load();
  }
  async function remove(t: any) {
    if (!confirm(`Delete ${t.full_name}?`)) return;
    const { error } = await supabase.from("teachers").delete().eq("id", t.id);
    if (error) return toast.error(error.message);
    toast.success("Teacher deleted");
    load();
  }

  function openLogin(t: any) {
    setLoginFor(t);
    setLoginForm({ email: t.email ?? "", password: "" });
  }
  async function saveLogin(e: React.FormEvent) {
    e.preventDefault();
    if (!loginFor) return;
    setLoginSaving(true);
    try {
      await createLogin({ data: { teacherId: loginFor.id, email: loginForm.email, password: loginForm.password } });
      toast.success(`${loginFor.full_name} can now sign in with ${loginForm.email}`);
      setLoginFor(null);
      load();
    } catch (err: any) {
      toast.error(err?.message ?? "Could not save the login");
    } finally {
      setLoginSaving(false);
    }
  }

  const pinned = PINNED_NAMES
    .map((n) => rows.find((t) => t.full_name === n))
    .filter(Boolean) as any[];
  const pinnedIds = new Set(pinned.map((t) => t.id));
  const q = search.trim().toLowerCase();
  const matches = (t: any) =>
    !q ||
    [t.full_name, t.email, t.phone, ...(t.assignedCourses ?? []).map((c: any) => `${c.name} ${c.departmentCode}`)].some((v) => (v ?? "").toString().toLowerCase().includes(q));
  const shownPinned = pinned.filter(matches);
  const remaining = rows.filter((t) => !pinnedIds.has(t.id)).filter(matches);

  return (
    <div className="space-y-6 min-w-0 catalogue-page">
      <div className="flex items-end justify-between gap-4 flex-wrap border-b-2 border-primary pb-6">
        <div>
          <p className="text-sm font-medium text-primary mb-2">EAU Gardo · Teaching faculty</p>
          <h1 className="text-3xl font-bold">Teachers</h1>
          <p className="text-muted-foreground mt-2">{rows.length} teachers · {rows.reduce((n, t) => n + t.assignedCourses.length, 0)} course assignments</p>
        </div>
        <Button onClick={openNew}>Add Teacher</Button>
      </div>
      <div className="max-w-2xl space-y-2">
        <Label htmlFor="teacher-search">Search</Label>
        <Input id="teacher-search" aria-label="Search teachers" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search teachers or courses…" className="bg-card" />
        <p className="text-xs text-muted-foreground">{shownPinned.length + remaining.length} teachers</p>
      </div>
      {shownPinned.length > 0 && <section className="catalogue-teachers"><TeacherTable rows={shownPinned} onEdit={openEdit} onDelete={remove} onLogin={openLogin} /></section>}
      <section className="catalogue-teachers"><TeacherTable rows={remaining} startIndex={shownPinned.length} onEdit={openEdit} onDelete={remove} onLogin={openLogin} /></section>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Edit Teacher" : "Add Teacher"}</DialogTitle></DialogHeader>
          <form onSubmit={save} className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="fn">Full name</Label>
              <Input id="fn" value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} required />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="sp">Specialty</Label>
              <Input id="sp" value={form.specialty} onChange={(e) => setForm({ ...form, specialty: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="em">Email</Label>
              <Input id="em" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="ph">Phone</Label>
              <Input id="ph" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="252906943912" />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? "Saving…" : "Save"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!loginFor} onOpenChange={(o) => !o && setLoginFor(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Teacher login access</DialogTitle></DialogHeader>
          <form onSubmit={saveLogin} className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Give {loginFor?.full_name} an email and password so they can sign in from the Teacher tab on the login page.
            </p>
            <div className="space-y-1.5">
              <Label htmlFor="lemail">Email</Label>
              <Input id="lemail" type="email" value={loginForm.email} onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })} required />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="lpass">Password</Label>
              <Input id="lpass" type="text" value={loginForm.password} onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })} placeholder="At least 6 characters" required />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setLoginFor(null)}>Cancel</Button>
              <Button type="submit" disabled={loginSaving}>{loginSaving ? "Saving…" : "Save login"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}