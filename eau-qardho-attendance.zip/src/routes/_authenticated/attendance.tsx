import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { buildAttendanceSheetGrid, ATTENDANCE_SHEET_PERIODS } from "@/lib/attendance-grid";

export const Route = createFileRoute("/_authenticated/attendance")({
  staticData: { sitemap: false },
  head: () => ({
    meta: [
      { title: "Monthly Attendance Sheet — EAU Gardo" },
      { name: "description", content: "EAU Gardo monthly attendance by week and class day, with course, lecturer and comments." },
      { property: "og:title", content: "Monthly Attendance Sheet — EAU Gardo" },
      { property: "og:description", content: "Weekly attendance for every Saturday–Wednesday class day at EAU Gardo." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AttendanceSheet,
});

type Status = "present" | "absent" | "excused";
const NEXT: Record<string, Status | ""> = { "": "present", present: "absent", absent: "excused", excused: "present" };
const LABEL: Record<string, string> = { present: "P", absent: "A", excused: "E" };
const PERIODS = ATTENDANCE_SHEET_PERIODS;

function AttendanceSheet() {
  const [depts, setDepts] = useState<any[]>([]);
  const [courses, setCourses] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [dept, setDept] = useState("");
  const [sem, setSem] = useState("");
  const [course, setCourse] = useState("");
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7));
  const [marks, setMarks] = useState<Record<string, Status>>({});
  const [dirty, setDirty] = useState<Set<string>>(new Set());
  const [saving, setSaving] = useState(false);
  const [notes, setNotes] = useState<Record<string, string>>({});

  const grid = useMemo(() => buildAttendanceSheetGrid(month), [month]);
  const dates = useMemo(() => grid.flat().filter(Boolean) as string[], [grid]);
  const selCourse = courses.find((c) => c.id === course);
  const dept0 = depts.find((d) => d.id === dept);

  useEffect(() => {
    supabase.from("departments").select("id,name").order("name").then(({ data }) => setDepts(data ?? []));
  }, []);

  useEffect(() => {
    setCourse("");
    if (!dept || !sem) { setCourses([]); setStudents([]); return; }
    supabase.from("courses").select("id,name,teacher_id,credit_hours,teachers(full_name)").eq("department_id", dept).eq("semester", Number(sem))
      .order("name").then(({ data }) => setCourses(data ?? []));
    supabase.from("students").select("id,full_name,student_no").eq("department_id", dept).eq("semester", Number(sem))
      .order("full_name").then(({ data }) => setStudents(data ?? []));
  }, [dept, sem]);

  useEffect(() => {
    setMarks({}); setDirty(new Set()); setNotes({});
    if (!course || !dates.length) return;
    supabase.from("attendance").select("student_id,date,status,remarks").eq("course_id", course)
      .gte("date", dates[0]).lte("date", dates[dates.length - 1]).limit(5000)
      .then(({ data }) => {
        const m: Record<string, Status> = {};
        (data ?? []).forEach((r: any) => { if (r.status !== "late") m[`${r.student_id}|${r.date}`] = r.status; });
        setMarks(m);
        const n: Record<string, string> = {};
        (data ?? []).forEach((r: any) => { if (r.remarks && !n[r.student_id]) n[r.student_id] = r.remarks; });
        setNotes(n);
      });
  }, [course, dates]);

  function toggle(sid: string, date: string) {
    const k = `${sid}|${date}`;
    setMarks((m) => ({ ...m, [k]: NEXT[m[k] ?? ""] as Status }));
    setDirty((d) => new Set(d).add(k));
  }

  function markColumn(date: string, s: Status) {
    setMarks((m) => { const n = { ...m }; students.forEach((st) => { n[`${st.id}|${date}`] = s; }); return n; });
    setDirty((d) => { const n = new Set(d); students.forEach((st) => n.add(`${st.id}|${date}`)); return n; });
  }

  async function save() {
    if (!dirty.size) { toast.info("No changes to save"); return; }
    setSaving(true);
    const rows = [...dirty].map((k) => {
      const [student_id, date] = k.split("|");
      return { student_id, course_id: course, teacher_id: selCourse?.teacher_id ?? null, date, status: marks[k], remarks: notes[student_id] || null, recorded_at: new Date().toISOString() };
    });
    const { error } = await supabase.from("attendance").upsert(rows, { onConflict: "student_id,course_id,date" });
    setSaving(false);
    if (error) toast.error(error.message);
    else { toast.success(`Saved ${rows.length} marks`); setDirty(new Set()); }
  }

  const monthName = new Date(`${month}-01T00:00:00`).toLocaleString("en", { month: "long", year: "numeric" });

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap justify-between items-start gap-3">
        <div>
        <h1 className="text-3xl font-bold">Attendance Sheet</h1>
        <p className="text-muted-foreground">{monthName}</p>
        </div>
      </div>

      <Card className="border-border/60" style={{ boxShadow: "var(--shadow-card)" }}>
        <CardContent className="p-5 grid grid-cols-1 md:grid-cols-4 gap-3">
          <Select value={dept} onValueChange={setDept}>
            <SelectTrigger><SelectValue placeholder="Department" /></SelectTrigger>
            <SelectContent>{depts.map((d) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={sem} onValueChange={setSem}>
            <SelectTrigger><SelectValue placeholder="Semester" /></SelectTrigger>
            <SelectContent>{[1, 2, 3, 4, 5, 6, 7, 8].map((s) => <SelectItem key={s} value={String(s)}>Semester {s}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={course} onValueChange={setCourse} disabled={!courses.length}>
            <SelectTrigger><SelectValue placeholder={courses.length ? "Subject" : "Pick dept & semester"} /></SelectTrigger>
            <SelectContent>{courses.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
          </Select>
          <Input type="month" value={month} onChange={(e) => setMonth(e.target.value)} />
        </CardContent>
      </Card>

      {course && (
        <Card className="border-border/60" style={{ boxShadow: "var(--shadow-card)" }}>
          <CardContent className="p-0">
            <div className="p-4 border-b text-center space-y-1">
              <div className="font-semibold">East Africa University – Gardo Campus</div>
              <div className="text-sm">Department of {dept0?.name} · Semester {sem}</div>
              <div className="text-sm flex flex-wrap justify-between gap-2 pt-2">
                <span>Subject: <b>{selCourse?.name}</b></span>
                <span><b>{monthName}</b> Attendance Evaluation</span>
               <span>Weeks: <b>1–{grid.length}</b></span>
                <span>Lecturer: <b>{selCourse?.teachers?.full_name ?? "—"}</b></span>
                {selCourse?.credit_hours != null && <span>Credit hours: <b>{selCourse.credit_hours}</b></span>}
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="attendance-week-grid w-full text-sm border-collapse">
                <thead>
                  <tr className="bg-accent/60">
                    <th rowSpan={2} className="border p-2 w-10">S/N</th>
                    <th rowSpan={2} className="border p-2 text-left min-w-[220px]">Student Name</th>
                    {grid.map((_, w) => <th key={w} colSpan={PERIODS} className={`border p-3 ${w % 2 ? "bg-secondary" : "bg-accent"}`} data-week-start>Week {w + 1}</th>)}
                    <th rowSpan={2} className="border p-2">P</th>
                    <th rowSpan={2} className="border p-2">A</th>
                    <th rowSpan={2} className="border p-2 min-w-[180px]">Comments</th>
                  </tr>
                  <tr className="bg-accent/30">
                    {grid.map((week, w) => week.map((d, p) => (
                      <th key={`${w}-${p}`} className="border p-1 font-medium min-w-14" data-week-start={p === 0 ? true : undefined} title={d ?? "No class"}>
                        <div>P {p + 1}</div>
                        {d ? (
                          <div className="flex gap-0.5 justify-center">
                            <Button variant="ghost" className="h-6 px-1 text-xs text-muted-foreground" title={`Mark all present on ${d}`} onClick={() => markColumn(d, "present")}>{d.slice(8)}✓</Button>
                          </div>
                        ) : <div className="text-[10px] text-muted-foreground">—</div>}
                      </th>
                    )))}
                  </tr>
                </thead>
                <tbody>
                  {students.map((s, i) => {
                    let pc = 0, ac = 0;
                    dates.forEach((d) => { const v = marks[`${s.id}|${d}`]; if (v === "present") pc++; else if (v === "absent") ac++; });
                    return (
                      <tr key={s.id} className="hover:bg-accent/20">
                        <td className="border p-1 text-center">{i + 1}</td>
                        <td className="border p-1 px-2 font-medium">{s.full_name}</td>
                        {grid.map((week, w) => week.map((d, p) => {
                          const v = d ? marks[`${s.id}|${d}`] ?? "" : "";
                          const cls = v === "present" ? "bg-primary/15 text-primary" : v === "absent" ? "bg-destructive/15 text-destructive" : v === "excused" ? "bg-secondary text-secondary-foreground" : "";
                          return (
                            <td key={`${w}-${p}`} className="border p-0 text-center" data-week-start={p === 0 ? true : undefined}>
                              {d ? (
                                <Button variant="ghost" onClick={() => toggle(s.id, d)} className={`w-full min-w-14 h-9 rounded-none px-1 font-semibold ${cls}`} aria-label={`${s.full_name} ${d}`}>
                                  {LABEL[v] ?? ""}
                                </Button>
                              ) : <span className="text-muted-foreground">·</span>}
                            </td>
                          );
                        }))}
                        <td className="border p-1 text-center text-primary">{pc}</td>
                        <td className="border p-1 text-center text-destructive">{ac}</td>
                        <td className="border p-1">
                          <input
                            className="w-full bg-transparent px-1 py-1 text-xs outline-none focus:bg-accent/40 rounded"
                            placeholder="e.g. on leave / sick"
                            value={notes[s.id] ?? ""}
                            onChange={(e) => setNotes((n) => ({ ...n, [s.id]: e.target.value }))}
                            onBlur={() => setDirty((d) => { const n = new Set(d); dates.forEach((dt) => { if (marks[`${s.id}|${dt}`]) n.add(`${s.id}|${dt}`); }); return n; })}
                          />
                        </td>
                      </tr>
                    );
                  })}
                  {!students.length && (
                    <tr><td colSpan={2 + grid.length * PERIODS + 3} className="text-center text-muted-foreground py-8">No students in this class.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
            <div className="p-4 border-t flex items-center gap-3">
              <span className="text-sm text-muted-foreground">{dirty.size ? `${dirty.size} unsaved changes` : "All saved"}</span>
              <Button onClick={save} disabled={saving} className="ml-auto">{saving ? "Saving..." : "Save Attendance"}</Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
