import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useDepartments } from "@/lib/queries";
import { calcStudent, periodRange, MAX_MARKS, type Period } from "@/lib/attendance-calc";

export const Route = createFileRoute("/_authenticated/attendance-report")({
  staticData: { sitemap: false },
  head: () => ({ meta: [
    { title: "Attendance Calculator — EAU Gardo" },
    { name: "description", content: "Calculate each student's attendance daily, weekly, monthly and per semester, with credit hours and marks out of 10." },
    { property: "og:title", content: "Attendance Calculator — EAU Gardo" },
    { property: "og:description", content: "Daily, weekly, monthly and semester attendance with credit hours and marks out of 10." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: CalculatorPage,
});

const PERIODS: { key: Period; label: string }[] = [
  { key: "daily", label: "Daily" },
  { key: "weekly", label: "Weekly" },
  { key: "monthly", label: "Monthly" },
  { key: "semester", label: "Semester" },
];

function CalculatorPage() {
  const { data: depts = [] } = useDepartments();
  const [dept, setDept] = useState("");
  const [sem, setSem] = useState("");
  const [course, setCourse] = useState("");
  const [period, setPeriod] = useState<Period>("semester");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const range = periodRange(period, date);

  const { data: courses = [] } = useQuery({
    queryKey: ["calc-courses", dept, sem],
    enabled: !!dept && !!sem,
    queryFn: async () => {
      const { data } = await supabase.from("courses").select("id, name, credit_hours, teachers(full_name)")
        .eq("department_id", dept).eq("semester", Number(sem)).order("name");
      return (data ?? []) as any[];
    },
  });
  const selected = courses.find((c) => c.id === course);
  const creditHours = Number(selected?.credit_hours ?? 4);

  const { data: students = [] } = useQuery({
    queryKey: ["calc-students", dept, sem],
    enabled: !!dept && !!sem,
    queryFn: async () => {
      const { data } = await supabase.from("students").select("id, full_name, student_no")
        .eq("department_id", dept).eq("semester", Number(sem)).order("full_name");
      return (data ?? []) as any[];
    },
  });

  const { data: records = [], isFetching } = useQuery({
    queryKey: ["calc-records", course, range.from, range.to],
    enabled: !!course,
    queryFn: async () => {
      const { data } = await supabase.from("attendance").select("student_id, date, status")
        .eq("course_id", course).gte("date", range.from).lte("date", range.to).limit(20000);
      return (data ?? []) as any[];
    },
  });

  const classesHeld = useMemo(() => new Set(records.map((r) => r.date)).size, [records]);
  const rows = useMemo(() => {
    const by = new Map<string, string[]>();
    records.forEach((r) => by.set(r.student_id, [...(by.get(r.student_id) ?? []), r.status]));
    return students.map((s) => ({ ...s, ...calcStudent(by.get(s.id) ?? [], creditHours) }));
  }, [records, students, creditHours]);

  function exportCsv() {
    const head = ["Student ID", "Student", "Present", "Absent", "Excused", "Hours attended", "Possible hours", "%", `Marks /${MAX_MARKS}`];
    const body = rows.map((r) => [r.student_no, r.full_name, r.present, r.absent, r.excused, r.attendedHours, r.possibleHours, r.pct, r.marks]);
    const csv = [head, ...body].map((l) => l.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    a.download = `attendance-${period}-${range.from}.csv`;
    a.click();
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Attendance Calculator</h1>
        <p className="text-muted-foreground mt-1">
          Each class counts the course credit hours. Marks = hours attended ÷ possible hours × {MAX_MARKS}.
        </p>
      </div>

      <Card className="rounded-2xl">
        <CardContent className="p-4 grid grid-cols-1 md:grid-cols-4 gap-3">
          <div>
            <div className="text-xs font-medium text-muted-foreground mb-1.5">Department</div>
            <Select value={dept} onValueChange={(v) => { setDept(v); setCourse(""); }}>
              <SelectTrigger><SelectValue placeholder="Choose department" /></SelectTrigger>
              <SelectContent>{(depts as any[]).map((d) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <div className="text-xs font-medium text-muted-foreground mb-1.5">Semester</div>
            <Select value={sem} onValueChange={(v) => { setSem(v); setCourse(""); }}>
              <SelectTrigger><SelectValue placeholder="Choose semester" /></SelectTrigger>
              <SelectContent>{[1, 2, 3, 4, 5, 6, 7, 8].map((n) => <SelectItem key={n} value={String(n)}>Semester {n}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <div className="text-xs font-medium text-muted-foreground mb-1.5">Course</div>
            <Select value={course} onValueChange={setCourse} disabled={!courses.length}>
              <SelectTrigger><SelectValue placeholder={dept && sem && !courses.length ? "No courses" : "Choose course"} /></SelectTrigger>
              <SelectContent>{courses.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <div className="text-xs font-medium text-muted-foreground mb-1.5">Date</div>
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </div>
          <div className="md:col-span-4 flex flex-wrap gap-2">
            {PERIODS.map((p) => (
              <Button key={p.key} variant={period === p.key ? "default" : "outline"} onClick={() => setPeriod(p.key)}>{p.label}</Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {selected && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: "Period", value: range.label },
            { label: "Classes held", value: classesHeld },
            { label: "Credit hours per class", value: `${creditHours} h` },
            { label: "Teacher", value: selected.teachers?.full_name ?? "—" },
          ].map((s) => (
            <Card key={s.label} className="rounded-2xl"><CardContent className="p-4">
              <div className="text-xs text-muted-foreground">{s.label}</div>
              <div className="font-semibold mt-1">{s.value}</div>
            </CardContent></Card>
          ))}
        </div>
      )}

      <Card className="rounded-2xl">
        <CardContent className="p-0">
          <div className="p-4 border-b flex items-center justify-between gap-2">
            <h3 className="font-semibold text-lg">Student attendance &amp; marks</h3>
            <Button variant="outline" onClick={exportCsv} disabled={!course || !rows.length}>Export Excel (CSV)</Button>
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-accent/60">
                  <TableHead>#</TableHead>
                  <TableHead>Student ID</TableHead>
                  <TableHead>Student</TableHead>
                  <TableHead className="text-right">Present</TableHead>
                  <TableHead className="text-right">Absent</TableHead>
                  <TableHead className="text-right">Excused</TableHead>
                  <TableHead className="text-right">Hours attended</TableHead>
                  <TableHead className="text-right">%</TableHead>
                  <TableHead className="text-right">Marks /{MAX_MARKS}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {course && rows.map((r, i) => (
                  <TableRow key={r.id}>
                    <TableCell>{i + 1}</TableCell>
                    <TableCell className="text-xs">{r.student_no}</TableCell>
                    <TableCell className="font-medium">{r.full_name}</TableCell>
                    <TableCell className="text-right text-primary">{r.present}</TableCell>
                    <TableCell className="text-right text-destructive">{r.absent}</TableCell>
                    <TableCell className="text-right">{r.excused}</TableCell>
                    <TableCell className="text-right">{r.attendedHours} / {r.possibleHours} h</TableCell>
                    <TableCell className="text-right">{r.pct}%</TableCell>
                    <TableCell className="text-right font-bold">{r.marks}</TableCell>
                  </TableRow>
                ))}
                {(!course || !rows.length) && (
                  <TableRow><TableCell colSpan={9} className="text-center text-muted-foreground py-8">
                    {!course ? "Choose department, semester and course." : isFetching ? "Calculating…" : "No students in this class."}
                  </TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
