import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import eauLogo from "@/assets/eau-logo-fast.webp.asset.json";
import eauCampus from "@/assets/eau-campus-light.webp.asset.json";
import { loginEmail } from "@/lib/login-email";

export const Route = createFileRoute("/auth")({
  staticData: { sitemap: true },
  head: () => ({
    meta: [
      { title: "Sign in — EAU Attendance System" },
      { name: "description", content: "Sign in to the East Africa University attendance system." },
      { property: "og:title", content: "Sign in — EAU Attendance System" },
      { property: "og:description", content: "Sign in to East Africa University Gardo attendance management." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
    links: [
      // LCP element on this page is the campus backdrop — discover it early.
      { rel: "preload", as: "image", href: eauCampus.url, fetchPriority: "high" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"admin" | "teacher">("admin");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [loginError, setLoginError] = useState("");
  const [forgotOpen, setForgotOpen] = useState(false);
  const [resetEmail, setResetEmail] = useState("");
  const [sending, setSending] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/dashboard" });
    });
  }, []);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoginError("");
    let email: string;
    try {
      email = loginEmail(username, mode);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Enter a valid email address.");
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      const message = error.code === "invalid_credentials" || /invalid login credentials/i.test(error.message)
        ? (mode === "teacher" ? "Incorrect email or password. Please try again." : "Incorrect username or password. Please try again.")
        : error.message;
      setLoginError(message);
      return;
    }
    toast.success("Welcome back");
    navigate({ to: "/dashboard" });
  }

  async function handleForgot(e: React.FormEvent) {
    e.preventDefault();
    if (!resetEmail.includes("@")) {
      toast.error("Enter the email address linked to your account");
      return;
    }
    setSending(true);
    const { error } = await supabase.auth.resetPasswordForEmail(resetEmail, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setSending(false);
    if (error) return toast.error(error.message);
    toast.success("If that account exists, a reset link has been sent.");
    setForgotOpen(false);
  }

  return (
    <div className="min-h-screen w-full flex items-center justify-center relative overflow-hidden bg-background">
      <img src={eauCampus.url} alt="" width={1280} height={853} fetchPriority="high" decoding="async" className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-primary/70" />

      <div className="relative z-10 w-full max-w-md mx-4 my-6 rounded-lg bg-card shadow-elegant border border-border p-6 sm:p-8">
        <div className="flex flex-col items-center text-center">
          <img
            src={eauLogo.url}
            alt="East Africa University logo"
            width={96}
            height={96}
            fetchPriority="high"
            decoding="async"
            className="h-24 w-24 object-contain"
          />
          <h1 className="mt-4 text-2xl font-bold text-foreground">East Africa University – Gardo Campus</h1>
          <p className="text-sm text-muted-foreground">Attendance Management System</p>
        </div>

        <div className="mt-6 grid grid-cols-2 gap-1 rounded-lg bg-muted p-1">
          {(["admin", "teacher"] as const).map((m) => (
            <Button
              key={m}
              type="button"
              variant="ghost"
              onClick={() => { setMode(m); setUsername(""); setPassword(""); setLoginError(""); }}
              className={`h-9 rounded-md text-sm font-medium capitalize transition ${
                mode === m ? "bg-card text-primary shadow-sm" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {m}
            </Button>
          ))}
        </div>

        <form onSubmit={handleLogin} className="mt-6 space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="username">{mode === "teacher" ? "Email" : "Username"}</Label>
            <Input
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder={mode === "teacher" ? "Enter your email address" : "Enter your username"}
              type={mode === "teacher" ? "email" : "text"}
              autoComplete="username"
              required
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" autoComplete="current-password" required />
          </div>
          {loginError && <p role="alert" className="text-sm text-destructive">{loginError}</p>}
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? "Signing in..." : "Sign in"}
          </Button>
          <Button
            type="button"
            variant="link"
            onClick={() => setForgotOpen(true)}
            className="w-full text-xs text-center text-primary hover:underline"
          >
            Forgot password?
          </Button>
        </form>
      </div>

      <Dialog open={forgotOpen} onOpenChange={setForgotOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Reset your password</DialogTitle></DialogHeader>
          <form onSubmit={handleForgot} className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Enter your account email and we will send you a link to choose a new password.
            </p>
            <Input
              type="email"
              placeholder="you@eau.edu.so"
              value={resetEmail}
              onChange={(e) => setResetEmail(e.target.value)}
              required
            />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setForgotOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={sending}>{sending ? "Sending…" : "Send reset link"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Style hint for shadow
// (uses --shadow-elegant defined in styles.css)