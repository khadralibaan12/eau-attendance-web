import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { askAttendanceAssistant } from "@/lib/assistant.functions";
import type { AssistantScope } from "@/lib/assistant-scope";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

export function AttendanceAssistant({ scope, contextLabel }: { scope?: AssistantScope; contextLabel?: string }) {
  const [question, setQuestion] = useState("");
  const [history, setHistory] = useState<{ q: string; a: string }[]>([]);
  const askAssistant = useServerFn(askAttendanceAssistant);
  const ask = useMutation({
    mutationFn: (q: string) => askAssistant({ data: { question: q, scope } }),
    onSuccess: (response, q) => setHistory((previous) => [...previous, { q, a: response.answer }]),
  });
  function submit() {
    if (!question.trim() || ask.isPending) return;
    ask.mutate(question.trim());
    setQuestion("");
  }
  return <section className="border-y border-border py-5 space-y-4" aria-label="Attendance AI">
    <div className="flex flex-wrap items-center justify-between gap-3">
      <div>
        <h2 className="text-lg font-semibold">Attendance AI</h2>
        {contextLabel && <p className="text-sm text-muted-foreground">{contextLabel}</p>}
      </div>
      {history.length > 0 && <Button variant="ghost" disabled={ask.isPending} onClick={() => { setHistory([]); ask.reset(); }}>Clear conversation</Button>}
    </div>
    <div aria-live="polite" className="max-h-96 overflow-y-auto space-y-4">
      {history.map((entry, index) => <div key={index} className="space-y-2 border-b border-border pb-4">
        <p className="font-medium text-sm break-words">{entry.q}</p>
        <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">{entry.a}</p>
      </div>)}
      {ask.isPending && <p role="status" className="text-sm text-muted-foreground">AI-gu wuu eegayaa xogta xaadirka…</p>}
    </div>
    {ask.isError && <p role="alert" className="text-sm text-destructive">{ask.error instanceof Error ? ask.error.message : "Jawaabta lama helin. Mar kale isku day."}</p>}
    <form onSubmit={(event) => { event.preventDefault(); submit(); }} className="space-y-3">
      <Textarea aria-label="Su’aasha Attendance AI" placeholder="Weydii su’aashaada xaadirka…" value={question} onChange={(event) => setQuestion(event.target.value)} maxLength={1000} rows={3} />
      <div className="flex justify-end"><Button type="submit" disabled={!question.trim() || ask.isPending}>{ask.isPending ? "Sug…" : "Weydii AI"}</Button></div>
    </form>
  </section>;
}