import { Link, useRouterState } from "@tanstack/react-router";
import { useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useCurrentRole } from "@/lib/queries";
import eauLogo from "@/assets/eau-logo-sm.png.asset.json";
import { LayoutGrid, Building2, Users, BookOpen, GraduationCap, ClipboardCheck, LogOut, BarChart3, Bot, Settings, LifeBuoy } from "lucide-react";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarHeader, SidebarFooter,
  SidebarMenu, SidebarMenuButton, SidebarMenuItem,
} from "@/components/ui/sidebar";

const items = [
  { title: "Overview", url: "/dashboard", icon: LayoutGrid, adminOnly: false },
  { title: "Departments", url: "/departments", icon: Building2, adminOnly: false },
  { title: "Teachers", url: "/teachers", icon: Users, adminOnly: true },
  { title: "Courses", url: "/courses", icon: BookOpen, adminOnly: false },
  { title: "Students", url: "/students", icon: GraduationCap, adminOnly: false },
  { title: "Attendance Sheet", url: "/attendance", icon: ClipboardCheck, adminOnly: false },
  { title: "Attendance Calculator", url: "/attendance-report", icon: ClipboardCheck, adminOnly: false },
  { title: "Reports & Analysis", url: "/reports", icon: BarChart3, adminOnly: false },
  { title: "AI Assistant", url: "/assistant", icon: Bot, adminOnly: false },
  { title: "Settings", url: "/settings", icon: Settings, adminOnly: false },
  { title: "Help & Support", url: "/help", icon: LifeBuoy, adminOnly: false },
];

export function AppSidebar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const { data: me } = useCurrentRole();
  const visible = items.filter((i) => !i.adminOnly || me?.role !== "teacher");
  async function logout() {
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }
  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="border-b border-sidebar-border p-4">
        <div className="flex items-center gap-3">
          <div className="h-11 w-11 rounded-full bg-white grid place-items-center overflow-hidden shrink-0">
            <img
              src={eauLogo.url}
              alt="East Africa University logo"
              width={40}
              height={40}
              fetchPriority="high"
              decoding="async"
              className="h-10 w-10 object-contain"
            />
          </div>
          <div className="min-w-0 group-data-[collapsible=icon]:hidden">
            <div className="font-bold text-base leading-tight text-sidebar-foreground">EAU</div>
            <div className="text-xs text-sidebar-foreground/70 leading-tight">Attendance System</div>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent className="px-2 py-3">
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu className="gap-1">
              {visible.map((item) => {
                const Icon = item.icon;
                const active = pathname === item.url;
                return (
                  <SidebarMenuItem key={item.url}>
                    <SidebarMenuButton
                      asChild
                      isActive={active}
                      className="h-11 rounded-lg text-sidebar-foreground/85 hover:bg-sidebar-accent hover:text-sidebar-foreground data-[active=true]:bg-white data-[active=true]:text-primary data-[active=true]:font-semibold"
                    >
                      <Link to={item.url} className="flex items-center gap-3">
                        <Icon className="h-5 w-5 shrink-0" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-3 border-t border-sidebar-border">
        <button
          onClick={logout}
          className="flex items-center justify-center gap-2 w-full h-11 rounded-lg bg-white text-primary font-medium hover:bg-white/90 transition"
        >
          <LogOut className="h-4 w-4" />
          <span className="group-data-[collapsible=icon]:hidden">Sign out</span>
        </button>
      </SidebarFooter>
    </Sidebar>
  );
}