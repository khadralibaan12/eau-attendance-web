export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      attendance: {
        Row: {
          course_id: string
          created_at: string
          created_by: string | null
          date: string
          department_id: string | null
          id: string
          recorded_at: string
          remarks: string | null
          semester: number | null
          session_id: string | null
          status: Database["public"]["Enums"]["attendance_status"]
          student_id: string
          teacher_id: string | null
          updated_at: string
        }
        Insert: {
          course_id: string
          created_at?: string
          created_by?: string | null
          date: string
          department_id?: string | null
          id?: string
          recorded_at?: string
          remarks?: string | null
          semester?: number | null
          session_id?: string | null
          status: Database["public"]["Enums"]["attendance_status"]
          student_id: string
          teacher_id?: string | null
          updated_at?: string
        }
        Update: {
          course_id?: string
          created_at?: string
          created_by?: string | null
          date?: string
          department_id?: string | null
          id?: string
          recorded_at?: string
          remarks?: string | null
          semester?: number | null
          session_id?: string | null
          status?: Database["public"]["Enums"]["attendance_status"]
          student_id?: string
          teacher_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "attendance_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "class_sessions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attendance_teacher_id_fkey"
            columns: ["teacher_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          },
        ]
      }
      attendance_log: {
        Row: {
          action: string
          attendance_id: string | null
          changed_at: string
          changed_by: string | null
          course_id: string
          date: string
          department_id: string | null
          id: string
          new_status: Database["public"]["Enums"]["attendance_status"] | null
          old_status: Database["public"]["Enums"]["attendance_status"] | null
          semester: number | null
          student_id: string
        }
        Insert: {
          action: string
          attendance_id?: string | null
          changed_at?: string
          changed_by?: string | null
          course_id: string
          date: string
          department_id?: string | null
          id?: string
          new_status?: Database["public"]["Enums"]["attendance_status"] | null
          old_status?: Database["public"]["Enums"]["attendance_status"] | null
          semester?: number | null
          student_id: string
        }
        Update: {
          action?: string
          attendance_id?: string | null
          changed_at?: string
          changed_by?: string | null
          course_id?: string
          date?: string
          department_id?: string | null
          id?: string
          new_status?: Database["public"]["Enums"]["attendance_status"] | null
          old_status?: Database["public"]["Enums"]["attendance_status"] | null
          semester?: number | null
          student_id?: string
        }
        Relationships: []
      }
      class_sessions: {
        Row: {
          class_date: string
          course_id: string
          created_at: string
          end_time: string | null
          id: string
          lecturer_id: string | null
          semester_id: string | null
          start_time: string | null
          status: string
        }
        Insert: {
          class_date: string
          course_id: string
          created_at?: string
          end_time?: string | null
          id?: string
          lecturer_id?: string | null
          semester_id?: string | null
          start_time?: string | null
          status?: string
        }
        Update: {
          class_date?: string
          course_id?: string
          created_at?: string
          end_time?: string | null
          id?: string
          lecturer_id?: string | null
          semester_id?: string | null
          start_time?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "class_sessions_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "class_sessions_lecturer_id_fkey"
            columns: ["lecturer_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "class_sessions_semester_id_fkey"
            columns: ["semester_id"]
            isOneToOne: false
            referencedRelation: "semesters"
            referencedColumns: ["id"]
          },
        ]
      }
      courses: {
        Row: {
          attendance_max_marks: number
          code: string | null
          created_at: string
          credit_hours: number | null
          department_id: string
          id: string
          name: string
          semester: number
          teacher_id: string | null
        }
        Insert: {
          attendance_max_marks?: number
          code?: string | null
          created_at?: string
          credit_hours?: number | null
          department_id: string
          id?: string
          name: string
          semester: number
          teacher_id?: string | null
        }
        Update: {
          attendance_max_marks?: number
          code?: string | null
          created_at?: string
          credit_hours?: number | null
          department_id?: string
          id?: string
          name?: string
          semester?: number
          teacher_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "courses_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "courses_teacher_id_fkey"
            columns: ["teacher_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          },
        ]
      }
      departments: {
        Row: {
          code: string
          created_at: string
          description: string | null
          id: string
          name: string
        }
        Insert: {
          code: string
          created_at?: string
          description?: string | null
          id?: string
          name: string
        }
        Update: {
          code?: string
          created_at?: string
          description?: string | null
          id?: string
          name?: string
        }
        Relationships: []
      }
      enrollments: {
        Row: {
          course_id: string
          created_at: string
          id: string
          semester_id: string | null
          status: string
          student_id: string
        }
        Insert: {
          course_id: string
          created_at?: string
          id?: string
          semester_id?: string | null
          status?: string
          student_id: string
        }
        Update: {
          course_id?: string
          created_at?: string
          id?: string
          semester_id?: string | null
          status?: string
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "enrollments_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "enrollments_semester_id_fkey"
            columns: ["semester_id"]
            isOneToOne: false
            referencedRelation: "semesters"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "enrollments_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      lecturer_courses: {
        Row: {
          course_id: string
          created_at: string
          id: string
          lecturer_id: string
          semester_id: string | null
        }
        Insert: {
          course_id: string
          created_at?: string
          id?: string
          lecturer_id: string
          semester_id?: string | null
        }
        Update: {
          course_id?: string
          created_at?: string
          id?: string
          lecturer_id?: string
          semester_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "lecturer_courses_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lecturer_courses_lecturer_id_fkey"
            columns: ["lecturer_id"]
            isOneToOne: false
            referencedRelation: "teachers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lecturer_courses_semester_id_fkey"
            columns: ["semester_id"]
            isOneToOne: false
            referencedRelation: "semesters"
            referencedColumns: ["id"]
          },
        ]
      }
      semesters: {
        Row: {
          academic_year: string | null
          created_at: string
          end_date: string | null
          id: string
          name: string
          start_date: string | null
          status: string
        }
        Insert: {
          academic_year?: string | null
          created_at?: string
          end_date?: string | null
          id?: string
          name: string
          start_date?: string | null
          status?: string
        }
        Update: {
          academic_year?: string | null
          created_at?: string
          end_date?: string | null
          id?: string
          name?: string
          start_date?: string | null
          status?: string
        }
        Relationships: []
      }
      students: {
        Row: {
          class_code: string | null
          created_at: string
          department_id: string
          email: string | null
          full_name: string
          gender: string | null
          id: string
          phone: string | null
          photo_url: string | null
          semester: number
          student_no: string
        }
        Insert: {
          class_code?: string | null
          created_at?: string
          department_id: string
          email?: string | null
          full_name: string
          gender?: string | null
          id?: string
          phone?: string | null
          photo_url?: string | null
          semester: number
          student_no: string
        }
        Update: {
          class_code?: string | null
          created_at?: string
          department_id?: string
          email?: string | null
          full_name?: string
          gender?: string | null
          id?: string
          phone?: string | null
          photo_url?: string | null
          semester?: number
          student_no?: string
        }
        Relationships: [
          {
            foreignKeyName: "students_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      support_reports: {
        Row: {
          category: string
          contact: string | null
          created_at: string
          id: string
          message: string
          name: string
          status: string
          user_id: string
        }
        Insert: {
          category?: string
          contact?: string | null
          created_at?: string
          id?: string
          message: string
          name: string
          status?: string
          user_id: string
        }
        Update: {
          category?: string
          contact?: string | null
          created_at?: string
          id?: string
          message?: string
          name?: string
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      teachers: {
        Row: {
          created_at: string
          email: string | null
          full_name: string
          id: string
          phone: string | null
          photo_url: string | null
          specialty: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          email?: string | null
          full_name: string
          id?: string
          phone?: string | null
          photo_url?: string | null
          specialty?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          email?: string | null
          full_name?: string
          id?: string
          phone?: string | null
          photo_url?: string | null
          specialty?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      attendance_class_history: {
        Args: { p_dept: string; p_sem: number }
        Returns: {
          absent: number
          course_id: string
          course_name: string
          day: string
          present: number
        }[]
      }
      attendance_course_stats: {
        Args: {
          p_dept?: string
          p_from?: string
          p_sem?: number
          p_to?: string
        }
        Returns: {
          absent: number
          course_id: string
          course_name: string
          pct: number
          present: number
          teacher_name: string
          total: number
        }[]
      }
      attendance_daily_stats: {
        Args: {
          p_course?: string
          p_dept?: string
          p_from?: string
          p_sem?: number
          p_to?: string
        }
        Returns: {
          absent: number
          day: string
          pct: number
          present: number
        }[]
      }
      attendance_monthly_report: {
        Args: { p_course: string; p_month: string }
        Returns: {
          absent: number
          completed: number
          late: number
          marks: number
          pct: number
          present: number
          student_id: string
          student_name: string
          student_no: string
        }[]
      }
      attendance_student_lookup: {
        Args: { p_query: string }
        Returns: {
          department_name: string
          semester: number
          student_id: string
          student_name: string
          student_no: string
        }[]
      }
      attendance_student_stats: {
        Args: {
          p_course?: string
          p_dept?: string
          p_from?: string
          p_sem?: number
          p_to?: string
        }
        Returns: {
          absent: number
          department_id: string
          department_name: string
          pct: number
          present: number
          semester: number
          student_id: string
          student_name: string
          student_no: string
          total: number
        }[]
      }
      course_attendance_marks: {
        Args: { p_course: string }
        Returns: {
          absent: number
          completed: number
          late: number
          marks: number
          max_marks: number
          pct: number
          present: number
          student_id: string
          student_name: string
          student_no: string
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      student_attendance_summary: {
        Args: { p_student: string }
        Returns: {
          absent: number
          course_id: string
          course_name: string
          present: number
          teacher_name: string
        }[]
      }
    }
    Enums: {
      app_role: "admin" | "teacher" | "viewer"
      attendance_status: "present" | "absent" | "late" | "excused"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "teacher", "viewer"],
      attendance_status: ["present", "absent", "late", "excused"],
    },
  },
} as const
