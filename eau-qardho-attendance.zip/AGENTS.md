<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Attendance Sheet uses a fixed-layout adapter over the shared Saturday-based monthly calendar helper; preserve the full calendar and stored records independently of visible sheet dimensions, and test calendar/layout rules when changing them.
- The AI Assistant uses Claude via the Lovable AI gateway /v1/messages (@ai-sdk/anthropic, streamed); answers are grounded only in DB RPC data. Why: user chose Claude.
- Attendance Sheet does not mount the AI conversation panel; keep the standalone assistant independent. Why: the user removed the embedded AI section.
- Login identifier validation lives in a shared browser-safe helper; teacher mode validates email without username aliasing and admin mode preserves existing aliases. Why: keep teacher credentials explicit without disrupting administrator access.
- No public server function may create accounts or use admin privileges; every privileged server fn requires requireSupabaseAuth + has_role admin. Why: previous public bootstrap exposed a known admin password.
- Course credit hours are nullable database values, independent of attendance duration; teaching import manifests match existing course keys and synchronize courses.teacher_id with lecturer_courses. Why: avoid invented hours, duplicate courses, and inconsistent lecturer assignments.

- Teachers displays live course assignments from courses.teacher_id and lecturer_courses, deduplicated by course ID; specialty remains available in the teacher editor. Why: keep the list aligned with actual teaching assignments without changing stored profiles.
- Courses catalogue uses department filters and semester-grouped vertical course rows with persistent edit/delete controls. Why: keep complete semester lists easy to scan and usable on touch screens.
- Courses and Teachers load user-keyed catalogue queries in route loaders and invalidate both catalogues after edits. Why: avoid repeated initial fetches while keeping assignments fresh and cached data isolated by account.
- Monthly reports use a shared full-month date range and department/semester/class/course filters for statistics and downloads, merging recorded totals with the filtered roster; class charts and rankings aggregate matching stored attendance. Why: include students with no records without inventing absences and keep every report surface aligned with the selected group.
